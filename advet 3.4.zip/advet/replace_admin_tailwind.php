<?php
$files = glob("d:/wamp/www/advet/admin/*.php");
$count = 0;
foreach($files as $file) {
    if (basename($file) === 'theme.php') continue;
    $content = file_get_contents($file);
    $content = preg_replace(
        '/<script>\s*tailwind\.config\s*=\s*\{.*?(?:#FDFCF9|DM Sans).*?\}\s*<\/script>/s',
        '<?= getAdminTailwindConfig(isset($settings) ? $settings : []) ?>',
        $content,
        -1,
        $reps
    );
    if ($reps > 0) {
        $content = str_replace('<body class="font-sans font-light min-h-screen bg-[#F4F1ED] flex">', '<body class="font-sans font-light min-h-screen bg-[#F4F1ED] flex" style="background-color: <?= $settings[\'theme_surface\'] ?? \'#F4F1ED\' ?>">', $content);
        file_put_contents($file, $content);
        $count++;
    }
}
echo "Replaced script in $count admin files.\n";
