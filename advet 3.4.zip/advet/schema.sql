-- FILE: schema.sql
-- Advet Buildwell — Full Database Setup Script

-- ─────────────────────────────────────────────
-- TABLE: users
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(150)  NOT NULL,
  email         VARCHAR(200)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  role          ENUM('admin','member','agent') NOT NULL DEFAULT 'member',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: properties
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS properties (
  id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title              VARCHAR(200)   NOT NULL,
  slug               VARCHAR(200)   NOT NULL UNIQUE,
  location           VARCHAR(200)   NOT NULL DEFAULT '',
  price              DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
  bedrooms           TINYINT UNSIGNED NOT NULL DEFAULT 0,
  bathrooms          TINYINT UNSIGNED NOT NULL DEFAULT 0,
  sqft               INT UNSIGNED   NOT NULL DEFAULT 0,
  status             ENUM('active','draft','sold') NOT NULL DEFAULT 'draft',
  category           ENUM('Home', 'Plot', 'Commercial') NOT NULL DEFAULT 'Home',
  listing_type       ENUM('Buy', 'Sell', 'Rent') NOT NULL DEFAULT 'Buy',
  description        TEXT,
  primary_material   VARCHAR(100)   DEFAULT NULL,
  secondary_material VARCHAR(100)   DEFAULT NULL,
  acoustic_stillness VARCHAR(100)   DEFAULT NULL,
  featured_image     VARCHAR(300)   DEFAULT NULL,
  gallery_images     JSON           DEFAULT NULL,
  agent_id           INT UNSIGNED   DEFAULT NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_property_agent FOREIGN KEY (agent_id)
    REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: inquiries
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inquiries (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  email       VARCHAR(200) NOT NULL,
  phone       VARCHAR(30)  DEFAULT NULL,
  message     TEXT         NOT NULL,
  user_id     INT UNSIGNED DEFAULT NULL,
  property_id INT UNSIGNED DEFAULT NULL,
  status      ENUM('new','read','replied') NOT NULL DEFAULT 'new',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_inquiry_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_inquiry_property FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: settings
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key   VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT         DEFAULT NULL,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: newsletter_subscribers
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email          VARCHAR(200) NOT NULL UNIQUE,
  subscribed_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: stories
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stories (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(200) NOT NULL,
  slug         VARCHAR(200) NOT NULL UNIQUE,
  excerpt      TEXT         DEFAULT NULL,
  content      LONGTEXT     DEFAULT NULL,
  cover_image  VARCHAR(300) DEFAULT NULL,
  meta_title   VARCHAR(255) DEFAULT NULL,
  meta_description TEXT DEFAULT NULL,
  meta_keywords    VARCHAR(255) DEFAULT NULL,
  published_at TIMESTAMP    NULL DEFAULT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: story_comments
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS story_comments (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  story_id      INT UNSIGNED NOT NULL,
  user_id       INT UNSIGNED DEFAULT NULL,
  user_name     VARCHAR(255) DEFAULT NULL,
  user_email    VARCHAR(255) DEFAULT NULL,
  comment_text  TEXT NOT NULL,
  status        ENUM('pending', 'approved', 'spam') NOT NULL DEFAULT 'pending',
  parent_id     INT UNSIGNED DEFAULT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_comment_story FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
  CONSTRAINT fk_comment_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: testimonials
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS testimonials (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(150) NOT NULL,
  affiliation     VARCHAR(150) DEFAULT NULL,
  experience_type ENUM('buying','selling','lease','other') NOT NULL DEFAULT 'other',
  content         TEXT         NOT NULL,
  rating          INT          DEFAULT 5,
  status          ENUM('pending','approved','declined') NOT NULL DEFAULT 'pending',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: team_members
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS team_members (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(150) NOT NULL,
  email           VARCHAR(200) DEFAULT NULL,
  phone           VARCHAR(50)  DEFAULT NULL,
  image_path      VARCHAR(300) DEFAULT NULL,
  facebook_url    VARCHAR(255) DEFAULT NULL,
  x_url           VARCHAR(255) DEFAULT NULL,
  instagram_url   VARCHAR(255) DEFAULT NULL,
  whatsapp_number VARCHAR(50)  DEFAULT NULL,
  threads_url     VARCHAR(255) DEFAULT NULL,
  socialvynk_url  VARCHAR(255) DEFAULT NULL,
  designation     VARCHAR(100) DEFAULT NULL,
  bio             TEXT         DEFAULT NULL,
  display_order   INT          DEFAULT 0,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: featured_projects
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS featured_projects (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  description   TEXT         DEFAULT NULL,
  image_path    VARCHAR(255) DEFAULT NULL,
  link_url      VARCHAR(255) DEFAULT NULL,
  display_order INT          DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: space_archetypes
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS space_archetypes (
  id int unsigned NOT NULL AUTO_INCREMENT,
  title varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  description text COLLATE utf8mb4_unicode_ci,
  image_path varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  display_order int DEFAULT '0',
  created_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: cron_logs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cron_logs (
  id int NOT NULL AUTO_INCREMENT,
  task_name varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  status varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'success',
  message text COLLATE utf8mb4_unicode_ci,
  executed_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: page_views
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS page_views (
  id int NOT NULL AUTO_INCREMENT,
  view_date date NOT NULL,
  views int DEFAULT '1',
  PRIMARY KEY (id),
  UNIQUE KEY unique_date (view_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: visitor_logs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS visitor_logs (
  id int NOT NULL AUTO_INCREMENT,
  ip_address varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  user_agent text COLLATE utf8mb4_unicode_ci,
  device_type varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  os varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  browser varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  page_url varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  visited_at timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: password_resets
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS password_resets (
  email VARCHAR(200) NOT NULL,
  token VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (email),
  INDEX (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: faqs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS faqs (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question      TEXT NOT NULL,
  answer        TEXT NOT NULL,
  display_order INT DEFAULT 0,
  status        ENUM('active', 'draft') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: albums
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS albums (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  slug          VARCHAR(255) NOT NULL UNIQUE,
  description   TEXT DEFAULT NULL,
  cover_image   VARCHAR(300) DEFAULT NULL,
  display_order INT DEFAULT 0,
  status        ENUM('active', 'draft') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- TABLE: album_images
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS album_images (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  album_id      INT UNSIGNED NOT NULL,
  image_path    VARCHAR(300) NOT NULL,
  display_order INT DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_album_images_album FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- SEEDS: settings
-- ─────────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value) VALUES
  ('site_name',             'Advet Buildwell'),
  ('accent_color',          '#899178'),
  ('contact_email',         'studio@advetbuildwell.com'),
  ('newsletter_enabled',    '1'),
  ('newsletter_frequency',  'weekly'),
  ('site_logo_text',        'Advet Buildwell'),
  ('site_favicon',          ''),
  ('mfa_enabled',           '0')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─────────────────────────────────────────────
-- SEEDS: sample properties
-- ─────────────────────────────────────────────
INSERT INTO properties (title, slug, location, price, bedrooms, bathrooms, sqft, status, description, primary_material, secondary_material, acoustic_stillness, featured_image, gallery_images) VALUES
(
  'The Obsidian Villa',
  'the-obsidian-villa',
  'Silverlake Hills',
  4250000.00,
  4,
  4,
  4200,
  'active',
  'Crafted with the precision of a watchmaker and the soul of an artist, The Obsidian Villa is a masterclass in monolithic modernism. Hidden behind a screen of ancient oaks in the Silverlake Hills, this sanctuary dissolves the boundary between the terrestrial and the atmospheric.',
  'Raw Travertine',
  'Blackened Steel',
  '94/100',
  'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800',
  '["https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=800","https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=800"]'
),
(
  'The Haven',
  'the-haven',
  'Coastal Bluffs',
  2800000.00,
  3,
  3,
  3100,
  'active',
  'Perched above the Pacific, The Haven is an exercise in restraint and panoramic living. Three bedroom suites, each capturing the horizon at a different angle.',
  'Lime Wash Plaster',
  'Smoked Oak',
  '89/100',
  'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800',
  '[]'
),
(
  'The Outline',
  'the-outline',
  'Urban Minimal District',
  1950000.00,
  2,
  2,
  2200,
  'active',
  'A study in precision and negative space. The Outline redefines urban living through a dialogue between glass, concrete, and curated silence.',
  'Exposed Concrete',
  'Tempered Glass',
  '88/100',
  'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&q=80&w=800',
  '[]'
);

-- ─────────────────────────────────────────────
-- SEEDS: sample stories
-- ─────────────────────────────────────────────
INSERT INTO stories (title, slug, excerpt, content, cover_image, published_at) VALUES
(
  'Designing for the Sun',
  'designing-for-the-sun',
  'How we trace the solar path across a plot of land before laying a single foundation stone, allowing natural rhythms to dictate the layout.',
  '<p>At Advet Buildwell, every design begins not with sketches but with a solar study. Before a foundation is laid, our architects spend months observing how light moves across the land. This deep respect for the sun\'s journey allows us to create homes that breathe naturally with the rhythms of each season.</p><p>The result is a living space that requires less artificial lighting and heating — a home that exists in quiet harmony with its environment.</p>',
  'https://images.unsplash.com/photo-1544457070-4cd773b4d71e?auto=format&fit=crop&q=80&w=800',
  '2026-01-15 09:00:00'
),
(
  'The Imperfection of Plaster',
  'the-imperfection-of-plaster',
  'Why we choose hand-troweled tadelakt walls over perfect dry-wall, embracing the human touch and subtle textures of organic materials.',
  '<p>In a world obsessed with perfection, Advet Buildwell celebrates the subtle imperfection of artisan plaster. Hand-troweled tadelakt — a Moroccan lime-based plaster — carries the fingerprints of its maker. Each wall tells a story of craft, patience, and human presence.</p><p>These surfaces age beautifully, developing a patina that no factory-finished panel can ever replicate. It is architecture as living art.</p>',
  'https://images.unsplash.com/photo-1595521624992-48a59aef95e3?auto=format&fit=crop&q=80&w=800',
  '2026-02-10 09:00:00'
);
