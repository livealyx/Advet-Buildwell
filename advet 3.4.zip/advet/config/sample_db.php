<?php
// config/sample_db.php — Template for Advet Buildwell configuration.
// Rename this file to db.php and update the credentials below.

// ── Dynamic BASE URL Detection ──────────────────────────────────────────────
if (!defined('BASE')) {
    // Robust detection: Find the relative web path from Document Root to the project folder
    $docRoot    = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/\\'));
    $projectDir = str_replace('\\', '/', dirname(__DIR__)); // dirname of config folder
    
    $basePath = '';
    if (str_starts_with($projectDir, $docRoot)) {
        $basePath = substr($projectDir, strlen($docRoot));
    }
    
    $base = '/' . ltrim(rtrim($basePath, '/\\'), '/') . '/';
    if ($base === '//') $base = '/';
    define('BASE', $base);
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');

// Upload settings
define('UPLOAD_DIR', realpath(__DIR__ . '/../assets/uploads/properties/') . DIRECTORY_SEPARATOR);
define('UPLOAD_URL_PREFIX', 'assets/uploads/properties/');

/**
 * Helper Functions
 * (Wrapped in function_exists guards to prevent redeclaration errors)
 */

if (!function_exists('getPDO')) {
    function getPDO(): PDO {
        static $pdo = null;
        if ($pdo === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        }
        return $pdo;
    }
}

if (!function_exists('slugify')) {
    function slugify(string $text): string {
        $text = mb_strtolower(trim($text), 'UTF-8');
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-');
    }
}

if (!function_exists('uniqueSlug')) {
    function uniqueSlug(PDO $pdo, string $base, ?int $excludeId = null): string {
        $slug = $base; $i = 2;
        while (true) {
            $sql  = 'SELECT COUNT(*) FROM properties WHERE slug = ?';
            $args = [$slug];
            if ($excludeId) { $sql .= ' AND id != ?'; $args[] = $excludeId; }
            $stmt = $pdo->prepare($sql); $stmt->execute($args);
            if ((int)$stmt->fetchColumn() === 0) break;
            $slug = $base . '-' . $i++;
        }
        return $slug;
    }
}

if (!function_exists('uploadPropertyImage')) {
    function uploadPropertyImage(array $file, string $uploadDir): array {
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/pjpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];
        $allowedExts  = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];

        if (!isset($file['tmp_name']) || $file['tmp_name'] === '') {
            return ['success' => false, 'message' => 'No file uploaded or temp path missing.'];
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errs = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds upload_max_filesize in php.ini.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds MAX_FILE_SIZE in HTML form.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
                UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.'
            ];
            return ['success' => false, 'message' => $errs[$file['error']] ?? 'Unknown PHP upload error.'];
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file['type'], $allowedTypes) && !in_array($ext, $allowedExts)) {
            return ['success' => false, 'message' => 'Invalid file type: ' . e($file['type']) . ' (.' . e($ext) . ').'];
        }

        if ($file['size'] > 5 * 1024 * 1024) {
            return ['success' => false, 'message' => 'File size exceeds 5MB limit.'];
        }

        $targetDir = rtrim($uploadDir, '/\\');
        if (!is_dir($targetDir)) {
            if (!mkdir($targetDir, 0777, true)) {
                return ['success' => false, 'message' => 'Failed to create upload directory.'];
            }
        }

        $filename = uniqid('prop_', true) . '.' . $ext;
        $dest = $targetDir . DIRECTORY_SEPARATOR . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            return ['success' => false, 'message' => 'Failed to move uploaded file. Check folder permissions.'];
        }

        return ['success' => true, 'path' => 'assets/uploads/properties/' . $filename];
    }
}

if (!function_exists('uploadSiteLogo')) {
    function uploadSiteLogo(array $file): string|false {
        $allowed = ['image/jpeg','image/png','image/svg+xml'];
        if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return false;
        if (!in_array($file['type'], $allowed, true)) return false;
        if ($file['size'] > 2 * 1024 * 1024) return false;

        $uploadDir = __DIR__ . '/../assets/uploads/site/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $filename = 'logo_' . time() . '.' . $ext;
        $dest     = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) return false;
        return 'assets/uploads/site/' . $filename;
    }
}

if (!function_exists('uploadFavicon')) {
    function uploadFavicon(array $file): string|false {
        $allowed = ['image/x-icon', 'image/png', 'image/vnd.microsoft.icon', 'image/svg+xml'];
        if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return false;
        if (!in_array($file['type'], $allowed, true)) {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['ico', 'png', 'svg'])) return false;
        }
        if ($file['size'] > 1 * 1024 * 1024) return false;
        $uploadDir = __DIR__ . '/../assets/uploads/site/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $filename = 'favicon_' . time() . '.' . $ext;
        $dest     = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) return false;
        return 'assets/uploads/site/' . $filename;
    }
}

if (!function_exists('formatPrice')) {
    function formatPrice(float $price): string {
        static $currency = null;
        if ($currency === null) {
            try {
                $currency = getPDO()->query("SELECT setting_value FROM settings WHERE setting_key='currency'")->fetchColumn();
            } catch (\Throwable $e) {}
            if (!$currency) $currency = 'USD';
        }

        if ($currency === 'INR') {
            $num = number_format($price, 0, '.', '');
            $num = preg_replace("/(\d)(?=(\d\d)+\d$)/", "$1,", $num);
            return '₹' . $num;
        }

        return '$' . number_format($price, 0, '.', ',');
    }
}

if (!function_exists('e')) {
    function e(mixed $val): string {
        return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('loadSettings')) {
    function loadSettings(PDO $pdo): array {
        $rows = $pdo->query('SELECT setting_key, setting_value FROM settings')->fetchAll();
        return array_column($rows, 'setting_value', 'setting_key');
    }
}

if (!function_exists('imgUrl')) {
    function imgUrl(?string $path): string {
        if (!$path) return 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800';
        if (preg_match('/^https?:\/\//i', $path)) return $path;
        $base = rtrim(BASE, '/');
        $p = ltrim($path, '/');
        return ($base ? $base . '/' : '/') . $p;
    }
}

if (!function_exists('timeGreeting')) {
    function timeGreeting(): string {
        $h = (int) date('G');
        if ($h < 12) return 'Good morning';
        if ($h < 17) return 'Good afternoon';
        return 'Good evening';
    }
}
?>
