/**
 * Advet Studio - Premium Asset Uploader
 * Features segmented dot progress indicators and a minimal, airy aesthetic.
 */

class AdvetUploader {
    constructor(element, options = {}) {
        this.input = typeof element === 'string' ? document.getElementById(element) : element;
        // Strict double-init guard
        if (!this.input || this.input.dataset.uploaderActive === "true") return;
        this.input.dataset.uploaderActive = "true";

        // Try to determine BASE from the script tag or fallback
        const script = document.querySelector('script[src*="uploader.js"]');
        const scriptPath = script ? script.src : '';
        const basePath = scriptPath.substring(0, scriptPath.indexOf('assets/js/uploader.js'));

        this.options = {
            dotCount: 15,
            maxFiles: 10,
            asyncUrl: basePath + 'actions/async-upload.php',
            ...options
        };

        this.container = null;
        this.dots = [];
        this.hint = null;
        this.previewGrid = null;
        this.isUploading = false;

        this._init();
    }

    _init() {
        this.isMini = this.input.getAttribute('data-uploader-mode') === 'mini';
        const wrapper = document.createElement('div');
        wrapper.className = 'advet-uploader-container' + (this.isMini ? ' mini-wrapper' : '');
        
        const zone = document.createElement('div');
        zone.className = 'upload-zone' + (this.isMini ? ' mini' : '');
        zone.innerHTML = `
            <div class="icon-stack">
                <div class="icon-bg"></div>
                <div class="icon-fg">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path opacity="0.4" d="M3 16L7.46967 11.5303C7.80923 11.1908 8.26978 11 8.75 11C9.23022 11 9.69077 11.1908 10.0303 11.5303L14 15.5M15.5 17L14 15.5M21 16L18.5303 13.5303C18.1908 13.1908 17.7302 13 17.25 13C16.7698 13 16.3092 13.1908 15.9697 13.5303L14 15.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M15.5 8C15.7761 8 16 7.77614 16 7.5C16 7.22386 15.7761 7 15.5 7M15.5 8C15.2239 8 15 7.77614 15 7.5C15 7.22386 15.2239 7 15.5 7M15.5 8V7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M3.69797 19.7472C2.5 18.3446 2.5 16.2297 2.5 12C2.5 7.77027 2.5 5.6554 3.69797 4.25276C3.86808 4.05358 4.05358 3.86808 4.25276 3.69797C5.6554 2.5 7.77027 2.5 12 2.5C16.2297 2.5 18.3446 2.5 19.7472 3.69797C19.9464 3.86808 20.1319 4.05358 20.302 4.25276C21.5 5.6554 21.5 7.77027 21.5 12C21.5 16.2297 21.5 18.3446 20.302 19.7472C20.1319 19.9464 19.9464 20.1319 19.7472 20.302C18.3446 21.5 16.2297 21.5 12 21.5C7.77027 21.5 5.6554 21.5 4.25276 20.302C4.05358 20.1319 3.86808 19.9464 3.69797 19.7472Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
            </div>
            <span class="upload-text">Drop your image here, or <span>browse</span></span>
            <span class="upload-subtext">Supports: PNG, JPG, JPEG, WEBP</span>
            <div class="progress-dots"></div>
            <div class="upload-hint">Preparing curation...</div>
        `;

        const grid = document.createElement('div');
        grid.className = 'preview-grid';

        wrapper.appendChild(zone);
        wrapper.appendChild(grid);

        // Hide original and insert new UI
        this.input.style.display = 'none';
        this.input.parentNode.insertBefore(wrapper, this.input.nextSibling);

        this.container = zone;
        this.previewGrid = grid;
        this.hint = zone.querySelector('.upload-hint');
        const dotsContainer = zone.querySelector('.progress-dots');

        // Create dots
        for (let i = 0; i < this.options.dotCount; i++) {
            const dot = document.createElement('div');
            dot.className = 'dot';
            dotsContainer.appendChild(dot);
            this.dots.push(dot);
        }

        // Event Listeners
        zone.addEventListener('click', () => this.input.click());
        zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('drag-over'); });
        zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            zone.classList.remove('drag-over');
            if (e.dataTransfer.files.length) {
                this._handleFiles(e.dataTransfer.files);
            }
        });

        this.input.addEventListener('change', () => {
            if (this.input.files.length) {
                this._handleFiles(this.input.files);
            }
        });
    }

    async _handleFiles(fileList) {
        if (this.isUploading) return;
        this.isUploading = true;

        const files = Array.from(fileList);
        const dotsContainer = this.container.querySelector('.progress-dots');
        dotsContainer.classList.add('active');
        this.hint.classList.add('active');
        if (this.isMini) this.container.classList.add('uploading');

        for (let i = 0; i < files.length; i++) {
            this.hint.innerText = this.isMini ? 'CURATING...' : `Curating ${files[i].name}...`;
            const path = await this._uploadFile(files[i]);
            this._addPreview(files[i], path);
        }

        this.hint.innerText = this.isMini ? 'READY' : 'Curation complete';
        this.isUploading = false;
        
        setTimeout(() => {
            if (this.isMini) this.container.classList.remove('uploading');
            dotsContainer.classList.remove('active');
            this.hint.classList.remove('active');
            this._setProgress(0);
        }, 2000);
    }

    _uploadFile(file) {
        return new Promise((resolve) => {
            const xhr = new XMLHttpRequest();
            const formData = new FormData();
            formData.append('file', file);

            xhr.open('POST', this.options.asyncUrl, true);

            xhr.upload.onprogress = (e) => {
                if (e.lengthComputable) {
                    const percent = (e.loaded / e.total) * 100;
                    this._setProgress(percent);
                }
            };

            xhr.onload = () => {
                let path = null;
                if (xhr.status === 200) {
                    try {
                        const res = JSON.parse(xhr.responseText);
                        if (res.success) {
                            path = res.path;
                            this._appendHiddenInput(path);
                        }
                    } catch (e) {}
                }
                resolve(path);
            };

            xhr.onerror = () => resolve();
            xhr.send(formData);
        });
    }

    _setProgress(percent) {
        const activeCount = Math.floor((percent / 100) * this.options.dotCount);
        this.dots.forEach((dot, i) => {
            if (i < activeCount) dot.classList.add('active');
            else dot.classList.remove('active');
        });
    }

    _addPreview(file, path = null) {
        const targetId = this.input.getAttribute('data-preview-target');
        const reader = new FileReader();

        reader.onload = (e) => {
            if (targetId) {
                const target = document.getElementById(targetId);
                const placeholder = document.getElementById(targetId + '-placeholder');
                if (target) {
                    target.src = e.target.result;
                    target.style.display = 'block';
                    if (placeholder) placeholder.style.display = 'none';
                }
            } else {
                const item = document.createElement('div');
                item.className = 'preview-item';
                item.style.backgroundImage = `url(${e.target.result})`;
                if (path) {
                    item.dataset.path = path; // Store the path on the preview item
                }
                
                const btn = document.createElement('div');
                btn.className = 'remove-btn';
                btn.innerHTML = '✕';
                btn.onclick = (e) => {
                    e.stopPropagation();
                    const itemPath = item.dataset.path;
                    if (itemPath) {
                        // Find and remove the corresponding hidden input
                        const hiddenInputs = this.input.form.querySelectorAll(`input[type="hidden"][value="${itemPath}"]`);
                        hiddenInputs.forEach(hidden => hidden.remove());
                    }
                    item.remove();
                };

                item.appendChild(btn);
                this.previewGrid.appendChild(item);
            }
        };
        reader.readAsDataURL(file);
    }

    _appendHiddenInput(path) {
        const name = this.input.name.replace('[]', '');
        const hiddenName = this.input.hasAttribute('multiple') || this.input.name.includes('[]') 
            ? `async_${name}[]` 
            : `async_${name}`;
            
        const hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = hiddenName;
        hidden.value = path;
        this.input.form.appendChild(hidden);
    }
}

// Auto-init for all image inputs
document.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    inputs.forEach(input => {
        if (input.dataset.uploaderActive) return;
        input.dataset.uploaderActive = "true";
        new AdvetUploader(input);
    });
});
