<?php
// FILE: upgrade.php
// A secure utility to run migration SQL on the live server.
// Usage: Visit domain.com/upgrade.php after uploading. 
// IMPORTANT: Delete this file immediately after successful execution.

session_start();
require_once __DIR__ . '/config/db.php';

// Simple Auth Check: Only Admins can run this
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die('<div style="font-family:sans-serif; padding:50px; text-align:center;">
            <h3>Restricted Access</h3>
            <p>Please log in as an administrator first.</p>
            <a href="auth/login.php">Login Here</a>
         </div>');
}

$pdo = getPDO();
$sqlFile = __DIR__ . '/migrate.sql';

if (!file_exists($sqlFile)) {
    die("Migration file (migrate.sql) not found in the root directory.");
}

$sql = file_get_contents($sqlFile);

try {
    // We use exec() for multiple statements. 
    // Note: Some server configurations might require splitting queries.
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec($sql);
    
    echo '<div style="font-family:sans-serif; max-width:600px; margin:50px auto; padding:40px; border-radius:30px; background:#f0f7f0; border:1px solid #d0e7d0; text-align:center;">
            <h2 style="color: #2d5a2d;">Migration Successful</h2>
            <p style="color: #4a6a4a; line-height:1.6;">Your database has been successfully updated with the latest branding and routing features.</p>
            <div style="margin:20px 0; padding:15px; background:#fff; border-radius:15px; font-size:12px; color:#e06c75;">
                <strong>CRITICAL SECURITY STEP:</strong><br>Delete <code>upgrade.php</code> and <code>migrate.sql</code> from your server immediately.
            </div>
            <a href="admin/settings.php" style="display:inline-block; margin-top:10px; padding:12px 25px; background:#2d5a2d; color:#fff; text-decoration:none; border-radius:10px; font-weight:bold; font-size:13px;">Go to Settings</a>
          </div>';
} catch (PDOException $e) {
    echo '<div style="font-family:sans-serif; max-width:600px; margin:50px auto; padding:40px; border-radius:30px; background:#fff5f5; border:1px solid #fed7d7;">
            <h2 style="color: #c53030;">Migration Failed</h2>
            <p style="color: #742a2a;">' . htmlspecialchars($e->getMessage()) . '</p>
            <p style="font-size:12px; color: #9b2c2c;">Check your SQL syntax or database permissions.</p>
          </div>';
}
