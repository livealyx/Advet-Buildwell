-- Migration script for live server
-- Includes: Slug columns, categories, and new Branding settings

-- 1. Ensure Slug columns exist in properties and stories
SET @column_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'slug' AND table_schema = DATABASE());
SET @query := IF(@column_exists = 0, 'ALTER TABLE properties ADD COLUMN slug VARCHAR(200) NOT NULL UNIQUE AFTER title', 'SELECT "Slug exists in properties"');
PREPARE stmt FROM @query; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @column_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'slug' AND table_schema = DATABASE());
SET @query := IF(@column_exists = 0, 'ALTER TABLE stories ADD COLUMN slug VARCHAR(200) NOT NULL UNIQUE AFTER title', 'SELECT "Slug exists in stories"');
PREPARE stmt FROM @query; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2. Ensure Category and Listing Type exist in properties
SET @column_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'category' AND table_schema = DATABASE());
SET @query := IF(@column_exists = 0, 'ALTER TABLE properties ADD COLUMN category ENUM("Home", "Plot", "Commercial") NOT NULL DEFAULT "Home" AFTER status', 'SELECT "Category exists"');
PREPARE stmt FROM @query; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @column_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'listing_type' AND table_schema = DATABASE());
SET @query := IF(@column_exists = 0, 'ALTER TABLE properties ADD COLUMN listing_type ENUM("Buy", "Sell", "Rent") NOT NULL DEFAULT "Buy" AFTER category', 'SELECT "Listing Type exists"');
PREPARE stmt FROM @query; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 3. Add new branding setting
INSERT INTO settings (setting_key, setting_value)
VALUES ('site_logo_text', 'Advet Buildwell'),
       ('site_favicon', '')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- 4. Create password_resets table
CREATE TABLE IF NOT EXISTS password_resets (
  email VARCHAR(200) NOT NULL,
  token VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (email),
  INDEX (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Add 'agent' to users.role ENUM (safe: only modifies column definition, data is preserved)
ALTER TABLE users MODIFY COLUMN role ENUM('admin','member','agent') NOT NULL DEFAULT 'member';

-- 6. Create faqs table
CREATE TABLE IF NOT EXISTS faqs (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  question      TEXT NOT NULL,
  answer        TEXT NOT NULL,
  display_order INT DEFAULT 0,
  status        ENUM('active', 'draft') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Gallery Tables
CREATE TABLE IF NOT EXISTS albums (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  slug          VARCHAR(255) NOT NULL UNIQUE,
  description   TEXT DEFAULT NULL,
  cover_image   VARCHAR(300) DEFAULT NULL,
  display_order INT DEFAULT 0,
  status        ENUM('active', 'draft') NOT NULL DEFAULT 'active',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS album_images (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  album_id      INT UNSIGNED NOT NULL,
  image_path    VARCHAR(300) NOT NULL,
  display_order INT DEFAULT 0,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_album_images_album_mgr FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Story SEO & Comments
SET @column_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'meta_title' AND table_schema = DATABASE());
SET @query := IF(@column_exists = 0, 'ALTER TABLE stories 
  ADD COLUMN meta_title VARCHAR(255) DEFAULT NULL AFTER cover_image,
  ADD COLUMN meta_description TEXT DEFAULT NULL AFTER meta_title,
  ADD COLUMN meta_keywords VARCHAR(255) DEFAULT NULL AFTER meta_description', 'SELECT "Story SEO columns exist"');
PREPARE stmt FROM @query; EXECUTE stmt; DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS story_comments (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  story_id      INT UNSIGNED NOT NULL,
  user_id       INT UNSIGNED DEFAULT NULL,
  user_name     VARCHAR(255) DEFAULT NULL,
  user_email    VARCHAR(255) DEFAULT NULL,
  comment_text  TEXT NOT NULL,
  status        ENUM('pending', 'approved', 'spam') NOT NULL DEFAULT 'pending',
  parent_id     INT UNSIGNED DEFAULT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_comment_story_alt FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
  CONSTRAINT fk_comment_user_alt FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. AI Chatbot Feature
CREATE TABLE IF NOT EXISTS chat_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(100) NOT NULL,
  user_id INT UNSIGNED DEFAULT NULL,
  role ENUM('user', 'assistant', 'system') NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (session_id),
  CONSTRAINT fk_chat_user_mgr FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO settings (setting_key, setting_value) VALUES
  ('ai_enabled',            '0'),
  ('ai_provider',           'gemini'),
  ('ai_api_key',            ''),
  ('ai_model',              'gemini-1.5-flash'),
  ('ai_system_instruction', 'You are "Ask Advet", an AI assistant for Advet Buildwell, a boutique real estate and architectural firm. Answer questions about properties, our services, and our philosophy (minimalist, human-centric, solar-driven design). Be premium, professional, and slightly poetic. If you don\'t know something, offer to connect them with a human agent.'),
  ('ai_chat_title',         'Ask Advet AI'),
  ('ai_welcome_msg',        'Welcome to Advet Studio. How can I assist you with your architectural or property inquiries today?')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);
