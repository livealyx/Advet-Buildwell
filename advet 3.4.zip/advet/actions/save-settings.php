<?php
// FILE: actions/save-settings.php
session_start();
require_once '../config/db.php';
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ' . BASE . 'auth/login.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE . 'admin/settings.php'); exit; }

$pdo      = getPDO();
$settings = $_POST['settings'] ?? [];

$allowed = [
    'site_name','site_logo_text','site_tagline','accent_color','contact_email','studio_address','studio_phone',
    'hours_mon_fri','hours_sat','hours_sun','social_instagram','social_linkedin','social_facebook','social_youtube',
    'social_socialvynk','newsletter_enabled','newsletter_frequency','inquiry_notifications','mfa_enabled','currency',
    'privacy_policy','terms_of_use','theme_background','theme_foreground','theme_surface','theme_muted','theme_sand','theme_accent_dark',
    'ai_enabled','ai_provider','ai_api_key', 'ai_model', 'ai_system_instruction', 'ai_chat_title', 'ai_welcome_msg'
];

$stmt = $pdo->prepare(
    "INSERT INTO settings (setting_key, setting_value)
         VALUES (?, ?)
     ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
);

foreach ($allowed as $key) {
    if (isset($settings[$key])) {
        $value = trim((string)$settings[$key]);
        $stmt->execute([$key, $value]);
    }
}

// Handle Logo Upload
$asyncLogo = $_POST['async_site_logo'] ?? null;
if ($asyncLogo) {
    $stmt->execute(['site_logo', $asyncLogo]);
} elseif (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
    $logoPath = uploadSiteLogo($_FILES['site_logo']);
    if ($logoPath) {
        $stmt->execute(['site_logo', $logoPath]);
    }
}

// Handle Favicon Upload
$asyncFav = $_POST['async_site_favicon'] ?? null;
if ($asyncFav) {
    $stmt->execute(['site_favicon', $asyncFav]);
} elseif (isset($_FILES['site_favicon']) && $_FILES['site_favicon']['error'] === UPLOAD_ERR_OK) {
    $favPath = uploadFavicon($_FILES['site_favicon']);
    if ($favPath) {
        $stmt->execute(['site_favicon', $favPath]);
    }
}

// Handle Hero Background Upload
if (isset($_FILES['site_hero_image'])) {
    if ($_FILES['site_hero_image']['error'] === UPLOAD_ERR_OK) {
        $heroPath = uploadHeroBackground($_FILES['site_hero_image']);
        if ($heroPath) {
            $stmt->execute(['site_hero_image', $heroPath]);
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Failed to process hero background. Please check the file type/size.'];
            header('Location: ' . BASE . 'admin/settings.php'); exit;
        }
    } elseif ($_FILES['site_hero_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Server upload error on hero image (Code: ' . $_FILES['site_hero_image']['error'] . ').'];
        header('Location: ' . BASE . 'admin/settings.php'); exit;
    }
}

$_SESSION['flash'] = ['type' => 'success', 'msg' => 'Settings saved successfully.'];
$redir = $_POST['redirect'] ?? 'admin/settings.php';
header('Location: ' . BASE . $redir);
exit;
