<?php
// FILE: public/property-detail.php
session_start();
require_once '../config/db.php';

$pdo = getPDO();
$id   = (int)($_GET['id'] ?? 0);
$slug = $_GET['slug'] ?? null;

if (!$id && !$slug) { header('Location: ' . BASE . 'properties'); exit; }

if ($slug) {
    $stmt = $pdo->prepare("SELECT * FROM properties WHERE slug = ? AND status = 'active'");
    $stmt->execute([$slug]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM properties WHERE id = ? AND status = 'active'");
    $stmt->execute([$id]);
}
$prop = $stmt->fetch();

if (!$prop) {
    // 404 in brand style
    $solidNav  = true;
    $pageTitle = 'Property Not Found';
    require_once '../includes/header.php';
    echo '<main class="flex-grow flex items-center justify-center pt-48 pb-32 px-6">
            <div class="text-center max-w-md">
              <p class="text-xs font-bold uppercase tracking-widest text-accent mb-6">404 · Not Found</p>
              <h1 class="text-5xl font-serif font-light italic mb-6">Sanctuary not found.</h1>
              <p class="text-muted font-light mb-12">This property may have been sold or removed from our collection.</p>
              <a href="' . BASE . 'properties" class="inline-flex items-center gap-2 text-sm font-medium border-b border-muted pb-1 text-muted hover:text-foreground hover:border-foreground transition-colors">Back to Properties</a>
            </div>
          </main>';
    require_once '../includes/footer.php';
    exit;
}

$gallery = json_decode($prop['gallery_images'] ?? '[]', true) ?: [];
$solidNav  = true;
$pageTitle = $prop['title'];
$pageDesc  = $prop['description'] ? substr(strip_tags($prop['description']), 0, 160) : 'View this curated property at Advet Buildwell.';
require_once '../includes/header.php';
?>

    <main class="flex-grow pt-32 pb-24">

        <!-- Hero Gallery -->
        <section class="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 mb-0 reveal">
            <div class="grid grid-cols-1 md:grid-cols-12 gap-6 h-auto md:h-[650px]">
                <div class="md:col-span-8 relative rounded-[2rem] overflow-hidden group">
                    <img src="<?= imgUrl($prop['featured_image']) ?>"
                         alt="<?= e($prop['title']) ?> — Cover"
                         class="w-full h-full object-cover transition-transform duration-[10s] group-hover:scale-105">
                </div>
                <div class="hidden md:grid md:col-span-4 grid-rows-2 gap-6">
                    <?php
                    $gallerySlots = array_slice($gallery, 0, 2);
                    $fallbacks    = ['https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=600','https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=600'];
                    for ($gi = 0; $gi < 2; $gi++):
                        $imgSrc = $gallerySlots[$gi] ?? $fallbacks[$gi];
                    ?>
                    <div class="relative rounded-[2rem] overflow-hidden group">
                        <img src="<?= imgUrl($imgSrc) ?>" alt="<?= e($prop['title']) ?> — View <?= $gi+2 ?>"
                             class="w-full h-full object-cover transition-transform duration-[10s] group-hover:scale-105">
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </section>

        <!-- Property Overview -->
        <section class="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 mb-32 pt-16 reveal" style="animation-delay:0.2s">
            <div class="grid grid-cols-1 min-[1200px]:grid-cols-3 gap-16 lg:gap-24 items-start">
                <div class="min-[1200px]:col-span-2">
                    <p class="text-xs font-medium uppercase tracking-[0.3em] text-accent mb-6">
                        <?= e($prop['location']) ?> · For Sale
                    </p>
                    <h1 class="text-5xl md:text-7xl font-serif font-light mb-8 italic"><?= e($prop['title']) ?></h1>

                    <div class="flex flex-wrap gap-10 border-y border-sand/50 py-10 mb-12">
                        <?php foreach ([['Area', number_format((int)$prop['sqft']) . ' SQFT'], ['Beds', (int)$prop['bedrooms'] . ' Suites'], ['Baths', (int)$prop['bathrooms'] . ' Full']] as $spec): ?>
                        <div>
                            <p class="text-[10px] uppercase tracking-widest text-muted mb-2"><?= $spec[0] ?></p>
                            <p class="text-2xl font-serif"><?= e($spec[1]) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="space-y-6 text-lg text-muted font-light leading-relaxed max-w-2xl">
                        <?php if ($prop['description']): ?>
                            <?php foreach (explode("\n\n", $prop['description']) as $para): ?>
                            <p><?= nl2br(e(trim($para))) ?></p>
                            <?php endforeach; ?>
                        <?php else: ?>
                        <p>A meticulously curated sanctuary, offered exclusively through Advet Buildwell.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Price Card -->
                <div class="min-[1200px]:col-span-1">
                    <div class="bg-surface/30 p-8 md:p-12 rounded-[3.5rem] border border-sand/60 min-[1200px]:sticky min-[1200px]:top-48 shadow-lg">
                        <p class="text-[10px] uppercase tracking-widest text-muted mb-2">Asking Price</p>
                        <h2 class="text-4xl font-serif mb-10"><?= formatPrice((float)$prop['price']) ?></h2>

                        <div class="space-y-4 mb-10">
                            <?php
                            $details = [
                                'Status'   => ucfirst($prop['status']),
                                'Bedrooms' => $prop['bedrooms'],
                                'Bathrooms'=> $prop['bathrooms'],
                                'Area'     => number_format((int)$prop['sqft']) . ' sqft',
                            ];
                            foreach ($details as $k => $v):
                            ?>
                            <div class="flex justify-between text-sm py-2 border-b border-sand/30">
                                <span class="text-muted"><?= $k ?></span>
                                <span class="font-medium"><?= e((string)$v) ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <a href="#inquiry-form" class="block w-full py-5 bg-foreground text-background text-center rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all shadow-xl">
                            Inquire Now
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Atmosphere & Materials -->
        <?php if ($prop['primary_material'] || $prop['secondary_material'] || $prop['acoustic_stillness']): ?>
        <section class="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 reveal">
            <div class="border-t border-sand pt-16 pb-16">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
                    <?php if ($prop['primary_material']): ?>
                    <div class="bg-surface/30 rounded-[2rem] p-8 border border-sand/30">
                        <p class="text-[10px] uppercase tracking-widest text-accent mb-3">Primary Material</p>
                        <p class="text-2xl font-serif"><?= e($prop['primary_material']) ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ($prop['secondary_material']): ?>
                    <div class="bg-surface/30 rounded-[2rem] p-8 border border-sand/30">
                        <p class="text-[10px] uppercase tracking-widest text-accent mb-3">Secondary Material</p>
                        <p class="text-2xl font-serif"><?= e($prop['secondary_material']) ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ($prop['acoustic_stillness']): ?>
                    <div class="bg-surface/30 rounded-[2rem] p-8 border border-sand/30">
                        <p class="text-[10px] uppercase tracking-widest text-accent mb-3">Acoustic Stillness</p>
                        <p class="text-2xl font-serif"><?= e($prop['acoustic_stillness']) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Gallery Grid (remaining) -->
        <?php if (count($gallery) > 2): ?>
        <section class="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 py-16 reveal">
            <p class="text-xs font-medium uppercase tracking-[0.3em] text-accent mb-6">Gallery</p>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <?php foreach (array_slice($gallery, 2) as $gImg): ?>
                <div class="group relative rounded-[2rem] overflow-hidden aspect-square">
                    <img src="<?= imgUrl($gImg) ?>" alt="Gallery" loading="lazy"
                         class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105">
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <!-- Inquiry Form -->
        <section id="inquiry-form" class="max-w-3xl mx-auto px-6 sm:px-12 py-24 reveal">
            <div class="bg-surface/30 p-10 md:p-14 rounded-[3rem] border border-sand/40">
                <p class="text-xs font-medium uppercase tracking-widest text-accent mb-4">Express Interest</p>
                <h2 class="text-4xl font-serif font-light mb-10 italic">Inquire about this <span class="text-muted">sanctuary.</span></h2>

                <form method="POST" action="<?= BASE ?>actions/submit-inquiry.php" class="space-y-6">
                    <input type="hidden" name="property_id" value="<?= (int)$prop['id'] ?>">

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Full Name *</label>
                            <input id="inq_name" type="text" name="name" required placeholder="Your name"
                                   class="w-full px-6 py-4 bg-background border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Email *</label>
                            <input id="inq_email" type="email" name="email" required placeholder="email@example.com"
                                   class="w-full px-6 py-4 bg-background border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                        </div>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Phone</label>
                        <input id="inq_phone" type="tel" name="phone" placeholder="+1 (555) 000-0000"
                               class="w-full px-6 py-4 bg-background border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Message *</label>
                        <textarea id="inq_message" name="message" required rows="5" placeholder="Tell us about your interest in this property…"
                                  class="w-full px-6 py-4 bg-background border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all resize-none"></textarea>
                    </div>
                    <button type="submit" id="inq_submit"
                            class="w-full py-5 bg-foreground text-background rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all shadow-lg transform hover:-translate-y-0.5">
                        Submit Inquiry
                    </button>
                </form>
            </div>
        </section>

    </main>

<?php require_once '../includes/footer.php'; ?>
