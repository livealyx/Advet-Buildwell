<?php
// FILE: public/contact.php
session_start();
require_once '../config/db.php';
$solidNav  = true;
$pageTitle = 'Contact Us';
$pageDesc  = 'Get in touch with the Advet Buildwell studio. We\'d love to hear about your next chapter.';
require_once '../includes/header.php';
?>

    <main class="flex-grow pt-40 pb-32">
        <div class="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">

            <!-- Page Header -->
            <div class="mb-24 reveal">
                <p class="text-xs font-medium uppercase tracking-widest text-accent mb-4">Get in Touch</p>
                <h1 class="text-5xl sm:text-7xl font-serif font-light leading-tight max-w-3xl">
                    Let's begin a <span class="italic text-muted">conversation.</span>
                </h1>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-24 items-start">

                <!-- Contact Form -->
                <div class="reveal reveal-delay-1">
                    <form method="POST" action="<?= BASE ?>actions/submit-inquiry.php" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Full Name *</label>
                                <input id="contact_name" type="text" name="name" required placeholder="Your name"
                                       class="w-full px-6 py-4 bg-surface/50 border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                            </div>
                            <div>
                                <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Email *</label>
                                <input id="contact_email" type="email" name="email" required placeholder="email@example.com"
                                       class="w-full px-6 py-4 bg-surface/50 border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Phone</label>
                            <input id="contact_phone" type="tel" name="phone" placeholder="+1 (555) 000-0000"
                                   class="w-full px-6 py-4 bg-surface/50 border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-2 ml-1">Message *</label>
                            <textarea id="contact_message" name="message" required rows="7" placeholder="Tell us about your vision, your timeline, and what you're looking for…"
                                      class="w-full px-6 py-4 bg-surface/50 border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent transition-all resize-none"></textarea>
                        </div>
                        <button type="submit" id="contact_submit"
                                class="w-full py-5 bg-foreground text-background rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all shadow-lg transform hover:-translate-y-0.5">
                            Send Message
                        </button>
                    </form>
                </div>

                <!-- Studio Info -->
                <div class="reveal reveal-delay-2">
                    <div class="space-y-16">
                        <div>
                            <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-6">Studio Location</p>
                            <p class="text-2xl font-serif font-light leading-relaxed">
                                <?= nl2br(e($siteSettings['studio_address'] ?? "1042 Minimalist Way\nLos Angeles, CA 90026")) ?>
                            </p>
                        </div>
                        <div>
                            <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-6">Contact</p>
                            <div class="space-y-3">
                                <p class="text-lg font-light">
                                    <?php $email = $siteSettings['contact_email'] ?? 'studio@advetbuildwell.com'; ?>
                                    <a href="mailto:<?= e($email) ?>" class="text-accent hover:text-accent-dark transition-colors border-b border-accent/30 hover:border-accent">
                                        <?= e($email) ?>
                                    </a>
                                </p>
                                <p class="text-lg font-light text-muted"><?= e($siteSettings['studio_phone'] ?? '+1 (424) 000-0000') ?></p>
                            </div>
                        </div>
                        <div>
                            <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-6">Studio Hours</p>
                            <div class="space-y-2 text-sm text-muted font-light">
                                <div class="flex justify-between border-b border-sand/30 pb-2">
                                    <span>Monday – Friday</span><span><?= e($siteSettings['hours_mon_fri'] ?? '9:00 AM – 6:00 PM') ?></span>
                                </div>
                                <div class="flex justify-between border-b border-sand/30 pb-2">
                                    <span>Saturday</span><span><?= e($siteSettings['hours_sat'] ?? '10:00 AM – 4:00 PM') ?></span>
                                </div>
                                <div class="flex justify-between pb-2">
                                    <span>Sunday</span><span class="italic"><?= e($siteSettings['hours_sun'] ?? 'By Appointment') ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="bg-surface/50 rounded-[2rem] p-8 border border-sand/30">
                            <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-4">Response Time</p>
                            <p class="text-sm font-light text-muted leading-relaxed">
                                We respond to all inquiries within 24 hours during studio hours. For urgent matters, please call us directly.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php require_once '../includes/footer.php'; ?>
