<?php
// FILE: public/changelog.php
session_start();
$solidNav  = true;
$pageTitle = 'Changelog';
$pageDesc  = 'Advet Buildwell platform updates and release notes.';
require_once '../includes/header.php';

$entries = [
    [
        'date'    => 'March 30, 2026',
        'version' => 'v3.4 — Cinematic Identity & Architectural Navigation',
        'changes' => [
            ['type' => 'new',    'note' => 'Homepage Hero Appearance: Launched a dedicated administration suite for managing the site\'s primary cinematic background with real-time previews and upload support.'],
            ['type' => 'update', 'note' => 'Premium Navigation 2.0: Implemented a sophisticated split-identity navigation bar. The homepage features a minimalist "Ice-White" frame, while inner pages adopt a robust branded accent outline for structural clarity.'],
            ['type' => 'new',    'note' => 'Centralized Identity Engine: Unified the site-wide brand accent (#899178) across all core CSS and PHP logic, ensuring perfect color consistency across the entire ecosystem.'],
            ['type' => 'update', 'note' => 'Navigational Clarity: Re-architected the central menu to include "Gallery", "Stories", and "Contact Us", while refining Properties into an intuitive Residential/Commercial dropdown.'],
            ['type' => 'new',    'note' => 'High-Definition Upload Suite: Expanded server infrastructure via .htaccess overrides to support 20MB cinematic asset uploads, paired with a new server-health diagnostic dashboard.'],
            ['type' => 'fix',    'note' => 'Filter Layering Stability: Resolved a z-index collision between the redesigned Properties Filter bar and the new absolute-positioned global navigation.'],
            ['type' => 'new',    'note' => 'Global Accent Injection: Developed a dynamic :root variable system in header.php, allowing the glassmorphism navigation to adapt instantly to database-stored brand colors.'],
        ],
    ],
    [
        'date'    => 'March 28, 2026',
        'version' => 'v3.3 — AI Chat Redesign & Intelligence Refinement',
        'changes' => [
            ['type' => 'new',    'note' => 'Launcher Bubble Redesign: Transitioned the AI launcher to a modern pill-shaped button featuring the Apple Intelligence mark and "Ask Advet" branding, optimized for premium tactile feedback.'],
            ['type' => 'new',    'note' => 'Custom Clear Chat Modal: Replaced standard browser dialogs with a bespoke, themed confirmation modal for a cohesive and professional history management experience.'],
            ['type' => 'update', 'note' => 'Bot Identity & SVG Refinement: Implemented a high-fidelity "floating" twotone SVG identity for Advet AI, removing background containers for a lighter, more modern chat persona.'],
            ['type' => 'fix',    'note' => 'Session Persistence Bug: Resolved a critical issue where new chats would merge with old history after page navigation by implementing a synchronized backend/frontend session clear.'],
            ['type' => 'new',    'note' => 'Quick-Prompt Chips: Added contextual suggestion pills ("Available properties", "Price ranges", "Schedule visit") above the input field that auto-dismiss after first use.'],
            ['type' => 'new',    'note' => '1-Hour Chat History TTL: Implemented an automatic purge system that deletes all chat messages from inactive sessions older than 1 hour.'],
            ['type' => 'update', 'note' => 'Chat Window Animation: Integrated spring-eased scale + fade transitions for a more organic and responsive interaction feel.'],
        ],
    ],
    [
        'date'    => 'March 27, 2026',
        'version' => 'v3.2 — Studio Stability & Asset Integrity',
        'changes' => [
            ['type' => 'update', 'note' => 'Commercial Transition: Rebranded the "Spaces" module to a dedicated "Commercial" portfolio, including route migrations and specialized navigation integration.'],
            ['type' => 'fix',    'note' => 'Commercial Link Integrity: Resolved a critical data-binding bug where Commercial listings were missing slugs, preventing detail page redirects.'],
            ['type' => 'update', 'note' => 'AI Chat Intelligence: Enhanced "ASK Advet" with RAG-lite location awareness and automated, clickable property linking in Markdown format.'],
            ['type' => 'update', 'note' => 'AI Connection Resilience: Implemented a PDO health-check and IPv4-first resolution to prevent "MySQL server has gone away" errors and improve response speeds.'],
            ['type' => 'update', 'note' => 'Chat Persistence Suite: Integrated LocalStorage-backed state management, allowing the AI chat window and history to persist across page refreshes and navigation.'],
            ['type' => 'fix',    'note' => 'Stories Visibility: Corrected a loop logic bug on the Stories page that was inadvertently hiding every third blog post.'],
            ['type' => 'fix',    'note' => 'Asset Resolution: Resolved broken gallery images on property detail pages by implementing a global path-mapping helper.'],
            ['type' => 'fix',    'note' => 'Duplicate Prevention: Engineered a state-aware upload handler that ignores redundant multi-part file submissions when asynchronous paths are present.'],
            ['type' => 'fix',    'note' => 'Cross-Platform Removal: Implemented slash-agnostic path comparison for image removal, ensuring full compatibility with Windows/WAMP server file systems.'],
            ['type' => 'update', 'note' => 'Uploader Sync: Linked UI preview removal (X button) directly to form submission state, preventing unwanted image saves after removal from the curation grid.'],
            ['type' => 'update', 'note' => 'System Guard: Added a singleton-pattern guard to the uploader component to prevent duplicate listener attachment during dynamic DOM mutations.'],
        ],
    ],
    [
        'date'    => 'March 26, 2026',
        'version' => 'v3.1 — Studio Integrity & Experience Refinement',
        'changes' => [
            ['type' => 'new',    'note' => 'Segmented Dot Uploader: Launched a new high-end image upload component featuring dynamic dot progress indicators and a "Curation Portal" aesthetic across all modules.'],
            ['type' => 'new',    'note' => 'Mini Mode Integration: Engineered specialized uploader variants for circular profile avatars and real-time image replacement for instant visual feedback.'],
            ['type' => 'fix',    'note' => 'Interface Integrity: Resolved vertical stacking, circular clipping, and flex-box collisions between legacy zones and the new global uploader.'],
            ['type' => 'update', 'note' => 'Team Profile Suite: Optimized real-time previews and storage handlers for team members, ensuring architectural consistency during curation.'],
            ['type' => 'update', 'note' => 'Responsiveness Suite: Optimized the uploader\'s spatial awareness for narrow columns and mobile environments across all Studio modules.'],
        ],
    ],
    [
        'date'    => 'March 25, 2026',
        'version' => 'v3.0 — Core Expansion & Content Engagement',
        'changes' => [
            ['type' => 'new',    'note' => 'AI Chat Integration: Launched "ASK Advet" - an intelligent real-estate advisory assistant for seamless property inquiries.'],
            ['type' => 'new',    'note' => 'Journal SEO Suite: Individual meta title, description, and keyword controls for every story to maximize search visibility.'],
            ['type' => 'new',    'note' => 'Comment & Response System: Integrated a fully functional engagement engine for stories, allowing readers to share insights directly on the journal.'],
            ['type' => 'new',    'note' => 'Story Moderation Panel: Launched a dedicated admin center to approve, delete, or mark comments as spam, ensuring high-quality site interactions.'],
            ['type' => 'update', 'note' => 'Pending Alert Badges: Added real-time notification dots in the All Stories list to signal new responses awaiting administrative review.'],
            ['type' => 'new',    'note' => 'Gallery & Album System: Launched a comprehensive photo management engine. Admins can create albums, bulk-upload photos, and select featured covers.'],
            ['type' => 'new',    'note' => 'FAQ Management: Integrated a fully manageable FAQ system from the dashboard with modern public accordion interface.'],
            ['type' => 'update', 'note' => 'Sidebar Categorization: Re-engineered admin navigation into logical industry-standard groups (Real Estate, CRM, Content, System).'],
        ],
    ],
    [
        'date'    => 'March 18, 2026',
        'version' => 'v2.5 — Profile System, Role Access Control & System Health',
        'changes' => [
            ['type' => 'new',    'note' => 'Live System Health Metrics: Dashboard now displays real-time data — DB ping latency (ms), live disk free space (GB), and live PHP memory usage against server limit, replacing all static placeholder values.'],
            ['type' => 'new',    'note' => 'Profile Picture System: All users (admin, agent, member) can upload a personal avatar from their profile page. Images securely stored in assets/uploads/users/ with 2MB size and format validation.'],
            ['type' => 'new',    'note' => 'Admin Profile Page: Created admin/profile.php — a dedicated settings panel for admins and agents to update their name, email, password, and avatar in one unified interface.'],
            ['type' => 'new',    'note' => 'Member Portal Profile: Normal registered members are directed to public/profile.php to manage their account details.'],
            ['type' => 'new',    'note' => 'uploadProfilePicture() Helper: Added a reusable, secure image upload utility to config/db.php specifically for user avatar handling.'],
            ['type' => 'update', 'note' => 'Role-Based Admin Sidebar: Sidebar navigation is now fully role-gated. Admins and agents see Overview, Listings, Inquiries, and Admin Control sections. Normal members see only My Profile.'],
            ['type' => 'update', 'note' => 'Role-Based Header Menu: Desktop dropdown and mobile tray now adapt per role. Admins/agents see Dashboard + My Profile + Logout. Normal members see only My Account button with My Profile + Logout (Dashboard hidden).'],
            ['type' => 'update', 'note' => 'Sidebar Avatar Widget: The bottom user widget in the admin sidebar now renders the user\'s profile picture as a round avatar (or initials fallback). Clicking it links directly to the profile page.'],
            ['type' => 'update', 'note' => 'Session Hydration: Login handler updated to SELECT * from users, ensuring newly added columns (profile_picture) are automatically included in the session without manual updates.'],
            ['type' => 'fix',    'note' => 'Member Dashboard Redirect: Members trying to access admin/dashboard.php are now redirected to the homepage instead of the login page, since they are already authenticated.'],
            ['type' => 'fix',    'note' => 'All 21 admin pages updated: Auth guards split — unauthenticated users go to login, wrong-role users (members on agent pages, non-admins on admin pages) are gracefully redirected to the homepage.'],
            ['type' => 'fix',    'note' => 'Profile Cancel Button: The Cancel button on the profile page is role-aware — members return to homepage, admins/agents return to the dashboard.'],
            ['type' => 'fix',    'note' => 'My Profile Link Routes: My Profile link in the header dropdown now correctly routes — members go to public/profile.php (Member Portal), staff go to admin/profile.php (Admin Panel).'],
            ['type' => 'update', 'note' => 'Contact Us Button Style: Updated the header Contact Us button (desktop) and Get in Touch button (mobile) to use brand olive color #899178 with off-white #FDFCF9 text for consistency with the design system.'],
        ],
    ],
    [
        'date' =>'March 18, 2026',
        'version' => 'v2.4 — Floating Glass Pill & Narrative Evolution',
        'changes' => [
            ['type' => 'new', 'note' => 'Floating Glass Pill Navigation: Implemented a trend-setting, detached capsule header with heavy glassmorphism and subtle radiant borders.'],
            ['type' => 'new', 'note' => 'Bilingual Narrative Architecture: Introduced a sophisticated bilingual (#NayaGharNayiZindagi) hero section for localized resonance.'],
            ['type' => 'update', 'note' => 'Interactive Hybrid Sub-menus: Re-engineered dropdown interactions with a CSS "Hover Bridge" and high-contrast Bento-style design.'],
            ['type' => 'fix', 'note' => 'Navigation Layering Stability: Corrected viewport clipping issues (overflow-hidden) to ensure absolute-positioned dropdowns render perfectly across all devices.'],
            ['type' => 'new', 'note' => 'Personalized Profile Integration: Launched a dedicated "My Profile" space for individual user identity, accessible via the new Management ecosystem.'],
            ['type' => 'update', 'note' => 'Unified Session Management: Re-engineered the "Dashboard" administrative link into a sophisticated Bento-style sub-menu, consolidating Profile and Logout utilities for a cleaner ecosystem.'],
        ]
    ],
    [
        'date' => 'March 17, 2026',
        'version' => 'v2.3 — Branding & Identity Evolution',
        'changes' => [
            ['type' => 'new', 'note' => 'Dual Logo Architecture: Introduced separate administrative controls for visual Icon Logos and sophisticated Editable Text branding.'],
            ['type' => 'new', 'note' => 'Secure Password Recovery: Implemented a comprehensive account restoration system with encrypted tokens and premium HTML notifications.'],
            ['type' => 'new', 'note' => 'Favicon Personalization: Added support for custom site favicons (.ico, .png, .svg) with real-time browser preview in settings.'],
            ['type' => 'update', 'note' => 'Typography Optimization: Integrated the "Outfit" font family globally while maintaining "Cormorant Garamond" for heritage branding elements.'],
            ['type' => 'update', 'note' => 'Offline-First Fonts: Migrated all typography to local storage, eliminating external dependencies and improving performance.'],
            ['type' => 'new', 'note' => 'Live Migration Engine: Developed a server-side upgrade utility (upgrade.php) for safe, one-click database synchronization on live servers.'],
            ['type' => 'update', 'note' => 'Advanced Utility Routing: Refined .htaccess to support clean URL mapping for utility files located in the project root.'],
            ['type' => 'fix', 'note' => 'Branding Continuity: Synchronized serif font-face declarations to ensure consistent identity across the digital ecosystem.'],
        ]
    ],
    [
        'date' => 'March 16, 2026',
        'version' => 'v2.2 — Deployment & Routing Optimization',
        'changes' => [
            ['type' => 'fix', 'note' => 'Search & Filter Reliability: Corrected form actions and refined .htaccess routing to ensure queries like search and filters work seamlessly with Clean URLs.'],
            ['type' => 'new', 'note' => 'Advanced SEO-friendly Slug Routing: Properties and stories now feature descriptive URLs (e.g. /property/post-name) instead of IDs.'],
            ['type' => 'new', 'note' => 'Implemented Clean URLs across the entire platform, automatically stripping .php extensions and redirecting index.php to root.'],
            ['type' => 'new', 'note' => 'Implemented Dynamic BASE URL Detection for seamless environment switching between localhost and live servers.'],
            ['type' => 'update', 'note' => 'Refined .htaccess with subfolder-agnostic routing rules and robust extensionless URL support.'],
            ['type' => 'update', 'note' => 'Enhanced Web Installer (install.php) with dynamic schema loading and secure administrative setup.'],
            ['type' => 'update', 'note' => 'Migrated global social media architecture to socialvynk.space domain.'],
            ['type' => 'fix', 'note' => 'Resolved critical "Member Profile" crash by synchronizing inquiries database schema.'],
            ['type' => 'fix', 'note' => 'Fixed featured property data visualization bugs on the root homepage.'],
            ['type' => 'fix', 'note' => 'Corrected post-installation redirection paths for subdirectory deployments.'],
        ]
    ],
    [
        'date' => 'March 14, 2026',
        'version' => 'v2.1 — Studio Intelligence & Team Evolution',
        'changes' => [
            ['type' => 'new', 'note' => 'Launched comprehensive Team Management system with full administrative CRUD controls.'],
            ['type' => 'update', 'note' => 'Optimized Legal Pages administration with a streamlined, stable Rich Text interface (Quill.js) for high-performance policy management.'],
            ['type' => 'new', 'note' => 'Implemented Studio Logo upload system supporting SVG, PNG, and JPG formats.'],
            ['type' => 'new', 'note' => 'Added "Inquiry Notifications" system with automated email alerts for administrators.'],
            ['type' => 'new', 'note' => 'Integrated global Social Media management (Facebook, Instagram, YouTube, LinkedIn, Socialvynk) with refined minimalist text-based integration.'],
            ['type' => 'new', 'note' => 'Developed "Studio Presence" management for dynamic location, phone, and hours across the platform.'],
            ['type' => 'new', 'note' => 'Created dynamic "Collective" team page with a sophisticated staggered layout.'],
            ['type' => 'update', 'note' => 'Developed intelligent social media cleansing for admin inputs (auto-stripping handles/URLs).'],
            ['type' => 'update', 'note' => 'Synchronized the "Collective Advisors" section on the About page with live database.'],
            ['type' => 'update', 'note' => 'Integrated automated platform URL prefixing for all major social media links.'],
            ['type' => 'update', 'note' => 'Implemented administrative controls for "Featured Projects" (Neighborhood Spotlight).'],
            ['type' => 'update', 'note' => 'Standardized system-wide iconography with premium Hugeicons optimized for accessibility.'],
            ['type' => 'fix', 'note' => 'Corrected timeline alignment issues on the public changelog interface.'],
            ['type' => 'fix', 'note' => 'Fixed "Profile" link visibility in navigation during transparent to solid state transitions.'],
            ['type' => 'fix', 'note' => 'Resolved data synchronization issue between Studio Presence settings and the contact page interface.'],
        ]
    ],
    [
        'date' => 'March 13, 2026',
        'version' => 'v2.0 — Administrative Expansion',
        'changes' => [
            ['type' => 'new', 'note' => 'Added system status indicators and real-time performance metrics to the dashboard.'],
            ['type' => 'new', 'note' => 'Integrated Market Analytics and Studio Settings administrative modules.'],
            ['type' => 'update', 'note' => 'Enhanced inquiry management with real-time status tracking and filtering.'],
            ['type' => 'update', 'note' => 'Unified system navigation with seamless "Our Team" routing and sidebar integration.'],
            ['type' => 'fix', 'note' => 'Resolved session persistence issues in the administrative authentication layer.'],
        ]
    ],
    [
        'date' => 'March 12, 2026',
        'version' => 'v1.0 — Platform Relaunch & CMS',
        'changes' => [
            ['type' => 'new', 'note' => 'Complete migration to PHP backend with robust MySQL database architecture.'],
            ['type' => 'new', 'note' => 'Launched the "Spaces" property management engine with dynamic listing capabilities.'],
            ['type' => 'update', 'note' => 'Established site-wide minimalist design system using local Tailwind CSS.'],
            ['type' => 'update', 'note' => 'Developed the "Stories" journal system for architectural narratives.'],
            ['type' => 'fix', 'note' => 'Optimized image loading performance across high-resolution property galleries.'],
        ]
    ],
];
?>

    <main class="flex-grow pt-40 pb-32">
        <div class="max-w-4xl mx-auto px-6 sm:px-12 lg:px-16">

            <!-- Header -->
            <div class="mb-20 reveal">
                <p class="text-xs font-medium uppercase tracking-widest text-accent mb-4">Platform History</p>
                <h1 class="text-5xl sm:text-6xl font-serif font-light leading-tight">
                    Changelog <span class="italic text-muted">& Releases</span>
                </h1>
            </div>

            <!-- Timeline -->
            <div class="relative">
                <div class="absolute left-[12rem] top-0 bottom-0 w-[1px] bg-sand hidden md:block"></div>

                <div class="space-y-20">
                    <?php foreach ($entries as $i => $e): ?>
                    <div class="relative flex flex-col md:flex-row gap-4 reveal" style="animation-delay: <?= $i * 0.1 ?>s">
                        <!-- Date -->
                        <div class="md:w-40 shrink-0 text-right">
                            <span class="text-[10px] font-bold uppercase tracking-widest text-accent leading-none inline-block pt-1.5"><?= e($e['date']) ?></span>
                        </div>

                        <!-- Dot -->
                        <div class="hidden md:flex items-start justify-center w-8 shrink-0 pt-1">
                            <div class="w-3 h-3 rounded-full bg-background border-2 border-accent shadow-[0_0_10px_rgba(var(--color-accent),0.2)]"></div>
                        </div>

                        <!-- Content -->
                        <div class="flex-1 bg-background border border-sand/40 rounded-[2rem] p-8 shadow-sm">
                            <h3 class="text-xl font-serif mb-6"><?= e($e['version']) ?></h3>
                            <ul class="space-y-4">
                                <?php foreach ($e['changes'] as $c): 
                                    $type = $c['type'];
                                    $badge = 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20'; // Update (Yellow)
                                    if ($type === 'new') $badge = 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20'; // New (Green)
                                    if ($type === 'fix') $badge = 'bg-red-500/10 text-red-700 border-red-500/20'; // Fix (Red)
                                ?>
                                <li class="flex items-start gap-4 text-sm text-muted font-light">
                                    <span class="inline-block px-2.5 py-1 rounded-md text-[8px] font-bold uppercase tracking-[0.1em] border <?= $badge ?> min-w-[55px] text-center mt-0.5">
                                        <?= e($type) ?>
                                    </span>
                                    <span class="flex-1 pt-0.5"><?= e($c['note']) ?></span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- CTA & Signature -->
            <div class="mt-24 pt-16 border-t border-sand/30 text-center pb-8">
                <p class="text-muted font-light mb-8">Have feedback or spotted a bug? We'd love to hear from you.</p>
                <a href="<?= BASE ?>contact.php" class="inline-flex items-center gap-3 bg-foreground text-background px-10 py-5 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-neutral-800 transition-all shadow-lg transform hover:-translate-y-0.5 mb-16">
                    Contact the Studio
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
                
                <div class="text-[10px] md:text-xs font-bold uppercase tracking-[0.2em] text-muted/60 transition-colors hover:text-muted flex justify-center items-center gap-2">
                    Design and Developed by 
                    <a href="https://github.com/livealyx" target="_blank" rel="noopener noreferrer" class="text-foreground border-b border-foreground/30 hover:border-accent hover:text-accent transition-colors pb-0.5">
                        Ashish Saini
                    </a>
                </div>
            </div>
        </div>
    </main>

<?php require_once '../includes/footer.php'; ?>
