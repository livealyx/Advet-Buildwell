<?php
// FILE: public/reviews.php
session_start();
$solidNav  = true;
$pageTitle = 'Share Your Experience';
$pageDesc  = 'Feedback form for Advet Buildwell clients.';
require_once '../includes/header.php';

$name = $_SESSION['user']['name'] ?? '';
?>

    <main class="flex-grow pt-40 pb-32">
        <div class="max-w-4xl mx-auto px-6 sm:px-12 lg:px-16 reveal">
            <!-- Header -->
            <header class="text-center mb-16">
                <p class="text-xs font-medium uppercase tracking-[0.3em] text-accent mb-6">Give Reviews</p>
                <h1 class="text-5xl md:text-6xl font-serif font-light leading-tight mb-8">
                    Share your <span class="italic text-muted">review.</span>
                </h1>
                <p class="text-lg text-muted font-light leading-relaxed max-w-2xl mx-auto">
                    We value the voices of those who dwell in our spaces. Share your experience with Advet Buildwell, and help us continue to refine our craft.
                </p>
            </header>

            <form action="<?= BASE ?>actions/submit-feedback.php" method="POST" class="bg-background border border-sand/40 rounded-[2.5rem] p-8 md:p-12 shadow-sm space-y-8 relative overflow-hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Your Name *</label>
                        <input type="text" name="name" required value="<?= e($name) ?>"
                               class="w-full px-6 py-4 bg-surface border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent font-light transition-all"
                               placeholder="Jane D.">
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Affiliation / Property (Optional)</label>
                        <input type="text" name="affiliation" 
                               class="w-full px-6 py-4 bg-surface border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent font-light transition-all"
                               placeholder="e.g. Architect, or The Haven">
                    </div>
                </div>
                
                <div>
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Experience Type *</label>
                    <select name="experience_type" required
                            class="w-full px-6 py-4 bg-surface border border-sand/30 rounded-2xl text-sm appearance-none focus:outline-none focus:border-accent font-light transition-all">
                        <option value="buying">Buying a Property</option>
                        <option value="selling">Selling a Property</option>
                        <option value="lease">Leasing / Renting</option>
                        <option value="other">Other / General</option>
                    </select>
                </div>

                <div class="space-y-4">
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-1 ml-1">Rating *</label>
                    <div class="flex flex-row-reverse justify-end gap-2 star-rating">
                        <?php for($i=5; $i>=1; $i--): ?>
                        <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" class="hidden peer" <?= $i === 5 ? 'checked' : '' ?>>
                        <label for="star<?= $i ?>" class="cursor-pointer text-sand peer-checked:text-accent peer-hover:text-accent hover:text-accent transition-all">
                            <svg class="w-8 h-8 fill-current" viewBox="0 0 24 24">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                        </label>
                        <?php endfor; ?>
                    </div>
                    <style>
                        .star-rating label:hover ~ label { color: #899178 !important; }
                    </style>
                </div>

                <div>
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Your Story / Review *</label>
                    <textarea name="content" rows="6" required
                              class="w-full px-6 py-4 bg-surface border border-sand/30 rounded-2xl text-sm focus:outline-none focus:border-accent font-light transition-all leading-relaxed"
                              placeholder="Tell us about the emotional and architectural experience of your journey with Advet..."></textarea>
                </div>

                <div class="pt-4 border-t border-sand/30 flex justify-end">
                    <button type="submit" class="px-10 py-4 bg-foreground text-background rounded-full text-xs font-bold uppercase tracking-widest hover:bg-accent transition-all shadow-xl hover:-translate-y-1">
                        Submit Review
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-12">
                <a href="<?= BASE ?>testimonials.php" class="text-xs uppercase tracking-widest font-bold text-accent hover:text-accent-dark transition-colors inline-block border-b border-accent/30 pb-1">
                    Read Testimonials →
                </a>
            </div>
        </div>
    </main>

<?php require_once '../includes/footer.php'; ?>
