<?php
// FILE: admin/settings.php
session_start();
require_once '../config/db.php';
if (empty($_SESSION['user'])) {
    header('Location: ' . BASE . 'auth/login.php'); exit;
}
if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: ' . BASE . 'index.php'); exit;
}

$pdo      = getPDO();
$settings = loadSettings($pdo);
$s = $settings; // shorthand
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings | Advet Studio</title>
    <script src="<?= BASE ?>assets/js/tailwind.min.js"></script>
    <?= getAdminTailwindConfig(isset($settings) ? $settings : []) ?>
    <link href="<?= BASE ?>assets/css/fonts.css" rel="stylesheet">
    <style>body{-webkit-font-smoothing:antialiased;} .form-reveal{opacity:0;transform:translateY(20px);animation:fadeIn .8s cubic-bezier(.2,.8,.2,1) forwards}@keyframes fadeIn{to{opacity:1;transform:none}} input:focus,textarea:focus,select:focus{outline:none;border-color:#899178;}</style>
</head>
<body class="font-sans font-light min-h-screen bg-[#F4F1ED] flex" style="background-color: <?= $settings['theme_surface'] ?? '#F4F1ED' ?>">
<?php require_once '../includes/flash.php'; ?>
<?php include __DIR__ . '/partials/sidebar.php'; ?>

<main class="flex-grow p-8 sm:p-12 overflow-y-auto">
    <div class="max-w-3xl mx-auto">
        <div class="mb-12 form-reveal">
            <p class="text-[10px] font-bold uppercase tracking-[0.4em] text-accent mb-4">System Configuration</p>
            <h1 class="text-4xl font-serif font-light italic">Studio <span class="text-muted">Settings</span></h1>
        </div>

        <form method="POST" action="<?= BASE ?>actions/save-settings.php" enctype="multipart/form-data" class="space-y-10 form-reveal" style="animation-delay:.1s">

            <!-- Branding -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Branding & Identity</h2>
                <div class="space-y-10">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Icon Logo (SVG/PNG/JPG)</label>
                            <div class="flex items-center gap-6">
                                <div class="w-24 h-24 rounded-2xl bg-surface border border-dashed border-sand/60 flex items-center justify-center overflow-hidden">
                                    <?php if (!empty($s['site_logo'])): ?>
                                        <img src="<?= imgUrl($s['site_logo']) ?>" class="max-w-[70%] max-h-[70%] object-contain" id="logoPreview">
                                    <?php else: ?>
                                        <div class="text-[9px] text-muted text-center px-4" id="logoPlaceholder">No Icon</div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1">
                                    <input type="file" name="site_logo" id="logoInput" accept=".png,.jpg,.jpeg,.svg" class="hidden">
                                    <button type="button" onclick="document.getElementById('logoInput').click()" 
                                            class="px-5 py-2.5 bg-surface border border-sand/30 rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-sand transition-colors mb-2">
                                        Upload
                                    </button>
                                    <p class="text-[8px] text-muted leading-relaxed">Max 2MB.</p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Favicon (.ico, .png, .svg)</label>
                            <div class="flex items-center gap-6">
                                <div class="w-24 h-24 rounded-2xl bg-surface border border-dashed border-sand/60 flex items-center justify-center overflow-hidden">
                                    <?php if (!empty($s['site_favicon'])): ?>
                                        <img src="<?= imgUrl($s['site_favicon']) ?>" class="max-w-[50%] max-h-[50%] object-contain" id="faviconPreview">
                                    <?php else: ?>
                                        <div class="text-[9px] text-muted text-center px-4" id="faviconPlaceholder">No Favicon</div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1">
                                    <input type="file" name="site_favicon" id="faviconInput" accept=".ico,.png,.svg" class="hidden">
                                    <button type="button" onclick="document.getElementById('faviconInput').click()" 
                                            class="px-5 py-2.5 bg-surface border border-sand/30 rounded-xl text-[9px] font-bold uppercase tracking-widest hover:bg-sand transition-colors mb-2">
                                        Upload
                                    </button>
                                    <p class="text-[8px] text-muted leading-relaxed">Max 1MB.</p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Text Logo</label>
                            <input type="text" name="settings[site_logo_text]" value="<?= e($s['site_logo_text'] ?? ($s['site_name'] ?? 'Advet Buildwell')) ?>"
                                   placeholder="Advet Studio"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                            <p class="text-[9px] text-muted mt-2 ml-1">Displayed next to the icon. Defaults to Site Name.</p>
                        </div>
                    </div>

                    <div class="pt-6 border-t border-sand/30">
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Site Name (SEO & General)</label>
                            <input type="text" name="settings[site_name]" value="<?= e($s['site_name'] ?? 'Advet Buildwell') ?>"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                        </div>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Site Tagline</label>
                        <input type="text" name="settings[site_tagline]" value="<?= e($s['site_tagline'] ?? '') ?>"
                               placeholder="Building dreams..."
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all text-muted">
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Properties Currency</label>
                        <select name="settings[currency]" class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all">
                            <option value="USD" <?= ($s['currency'] ?? 'USD') === 'USD' ? 'selected' : '' ?>>USD ($)</option>
                            <option value="INR" <?= ($s['currency'] ?? '') === 'INR' ? 'selected' : '' ?>>Rupees (₹)</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Homepage Hero -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Homepage Hero Appearance</h2>
                <div class="space-y-10">
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Main Hero Background (Cinematic Image)</label>
                        <div class="space-y-6">
                            <div class="relative w-full aspect-[21/9] rounded-3xl bg-surface border border-dashed border-sand/60 flex items-center justify-center overflow-hidden">
                                <?php if (!empty($s['site_hero_image'])): ?>
                                    <img src="<?= imgUrl($s['site_hero_image']) ?>" class="w-full h-full object-cover" id="heroPreview">
                                    <div class="absolute inset-0 bg-black/10"></div>
                                <?php else: ?>
                                    <div class="text-[9px] text-muted text-center px-6" id="heroPlaceholder">
                                        <svg class="w-8 h-8 opacity-20 mx-auto mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                                        No Hero Background (Defaults to System Image)
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="flex items-center gap-4">
                                <input type="file" name="site_hero_image" id="heroInput" accept=".png,.jpg,.jpeg,.webp" class="hidden">
                                <button type="button" onclick="document.getElementById('heroInput').click()" 
                                        class="px-8 py-4 bg-accent text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg shadow-accent/20 hover:scale-[1.02] transition-all">
                                    Change Hero Background
                                </button>
                                <p class="text-[9px] text-muted max-w-[250px] leading-relaxed italic">Recommended: 1920x1080px or higher. Max 5MB (.webp preferred for performance)</p>
                            </div>
                            <!-- Server Environment Check -->
                            <div class="pt-4 mt-4 border-t border-sand/20 flex items-center gap-6">
                                <div>
                                    <p class="text-[8px] uppercase tracking-widest font-bold text-muted/40 mb-1">Max Upload</p>
                                    <p class="text-[10px] font-mono text-accent"><?= ini_get('upload_max_filesize') ?></p>
                                </div>
                                <div>
                                    <p class="text-[8px] uppercase tracking-widest font-bold text-muted/40 mb-1">Max Post</p>
                                    <p class="text-[10px] font-mono text-accent"><?= ini_get('post_max_size') ?></p>
                                </div>
                                <div class="flex-grow text-right">
                                    <p class="text-[8px] text-muted leading-relaxed">If these are smaller than your image, your local WAMP server will block the upload with a "Code 1" error.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Studio Presence -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Studio Presence</h2>
                <div class="space-y-6">
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Physical Address</label>
                        <textarea name="settings[studio_address]" rows="3"
                                  class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all resize-none"><?= e($s['studio_address'] ?? "1042 Minimalist Way\nLos Angeles, CA 90026") ?></textarea>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Studio Phone</label>
                            <input type="text" name="settings[studio_phone]" value="<?= e($s['studio_phone'] ?? '+1 (424) 000-0000') ?>"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Primary Email</label>
                            <input type="email" name="settings[contact_email]" value="<?= e($s['contact_email'] ?? 'studio@advetbuildwell.com') ?>"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                        </div>
                    </div>
                    <div class="pt-4 border-t border-sand/30">
                        <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-6 ml-1">Operating Hours</p>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <label class="block text-[9px] uppercase tracking-widest font-bold text-muted/60 mb-2 ml-1">Mon – Fri</label>
                                <input type="text" name="settings[hours_mon_fri]" value="<?= e($s['hours_mon_fri'] ?? '9:00 AM – 6:00 PM') ?>"
                                       class="w-full px-4 py-3 bg-surface/30 border border-sand/20 rounded-xl text-xs transition-all">
                            </div>
                            <div>
                                <label class="block text-[9px] uppercase tracking-widest font-bold text-muted/60 mb-2 ml-1">Saturday</label>
                                <input type="text" name="settings[hours_sat]" value="<?= e($s['hours_sat'] ?? '10:00 AM – 4:00 PM') ?>"
                                       class="w-full px-4 py-3 bg-surface/30 border border-sand/20 rounded-xl text-xs transition-all">
                            </div>
                            <div>
                                <label class="block text-[9px] uppercase tracking-widest font-bold text-muted/60 mb-2 ml-1">Sunday</label>
                                <input type="text" name="settings[hours_sun]" value="<?= e($s['hours_sun'] ?? 'By Appointment') ?>"
                                       class="w-full px-4 py-3 bg-surface/30 border border-sand/20 rounded-xl text-xs transition-all">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Newsletter -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Newsletter</h2>
                <div class="space-y-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium">Newsletter Enabled</p>
                            <p class="text-xs text-muted mt-1">Allow visitors to subscribe via the footer form.</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="hidden" name="settings[newsletter_enabled]" value="0">
                            <input type="checkbox" name="settings[newsletter_enabled]" value="1"
                                   <?= ($s['newsletter_enabled'] ?? '1') === '1' ? 'checked' : '' ?>
                                   class="sr-only peer">
                            <div class="w-11 h-6 bg-sand peer-focus:outline-none rounded-full peer peer-checked:bg-accent transition-all
                                        after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                        </label>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Send Frequency</label>
                        <select name="settings[newsletter_frequency]" class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all">
                            <?php foreach (['weekly'=>'Weekly','biweekly'=>'Bi-Weekly','monthly'=>'Monthly'] as $val=>$lab): ?>
                            <option value="<?= $val ?>" <?= ($s['newsletter_frequency'] ?? 'weekly') === $val ? 'selected' : '' ?>><?= $lab ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Accent Color</label>
                        <div class="flex items-center gap-4">
                            <input type="color" name="settings[accent_color]" id="accentColorPicker"
                                   value="<?= e($s['accent_color'] ?? '#899178') ?>"
                                   class="w-14 h-14 rounded-2xl border border-sand/30 cursor-pointer bg-surface/30 p-1">
                            <input type="text" id="accentColorHex" value="<?= e($s['accent_color'] ?? '#899178') ?>"
                                   placeholder="#899178"
                                   class="flex-1 px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all font-mono"
                                   oninput="document.getElementById('accentColorPicker').value=this.value">
                        </div>
                    </div>
                </div>
            </div>


            <!-- Social Media -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Social Media</h2>
                <div class="space-y-6">
                    <p class="text-[10px] text-muted italic mb-4 ml-1">Enter your platform usernames. Leave blank to hide the icon from the footer.</p>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Instagram</label>
                            <div class="relative">
                                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-muted/40 text-xs">@</span>
                                <input type="text" name="settings[social_instagram]" value="<?= e($s['social_instagram'] ?? '') ?>"
                                       class="w-full pl-10 pr-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">LinkedIn</label>
                            <div class="relative">
                                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-muted/40 text-[9px]">company/</span>
                                <input type="text" name="settings[social_linkedin]" value="<?= e($s['social_linkedin'] ?? '') ?>"
                                       placeholder="advet-buildwell"
                                       class="w-full pl-20 pr-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Facebook</label>
                            <input type="text" name="settings[social_facebook]" value="<?= e($s['social_facebook'] ?? '') ?>"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">YouTube</label>
                            <div class="relative">
                                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-muted/40 text-xs">@</span>
                                <input type="text" name="settings[social_youtube]" value="<?= e($s['social_youtube'] ?? '') ?>"
                                       class="w-full pl-10 pr-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                            </div>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Socialvynk</label>
                            <input type="text" name="settings[social_socialvynk]" value="<?= e($s['social_socialvynk'] ?? '') ?>"
                                   class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all text-accent font-medium">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Communication -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Communication</h2>
                <div class="space-y-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium">Inquiry Notifications</p>
                            <p class="text-xs text-muted mt-1">Receive an instant email at the primary address for every new inquiry.</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="hidden" name="settings[inquiry_notifications]" value="0">
                            <input type="checkbox" name="settings[inquiry_notifications]" value="1"
                                   <?= ($s['inquiry_notifications'] ?? '0') === '1' ? 'checked' : '' ?>
                                   class="sr-only peer">
                            <div class="w-11 h-6 bg-sand peer-focus:outline-none rounded-full peer peer-checked:bg-accent transition-all
                                        after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Security -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Security</h2>
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium">MFA Enabled</p>
                        <p class="text-xs text-muted mt-1">Require multi-factor authentication for admin logins.</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="hidden" name="settings[mfa_enabled]" value="0">
                        <input type="checkbox" name="settings[mfa_enabled]" value="1"
                               <?= ($s['mfa_enabled'] ?? '0') === '1' ? 'checked' : '' ?>
                               class="sr-only peer">
                        <div class="w-11 h-6 bg-sand peer-focus:outline-none rounded-full peer peer-checked:bg-accent transition-all
                                    after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                    </label>
                </div>
            </div>

            <!-- Save -->
            <div class="flex gap-4 pt-4">
                <button type="submit"
                        class="flex-1 py-5 bg-foreground text-background rounded-2xl text-xs font-bold uppercase tracking-[0.2em] transform hover:-translate-y-1 transition-all shadow-xl">
                    Save Settings
                </button>
            </div>
        </form>
    </div>
</main>

<script>
document.getElementById('accentColorPicker').addEventListener('input', function(){
    document.getElementById('accentColorHex').value = this.value;
});

document.getElementById('logoInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            let container = document.querySelector('.w-24.h-24'); // Match updated logo container
            let preview = document.getElementById('logoPreview');
            if (!preview) {
                preview = document.createElement('img');
                preview.id = 'logoPreview';
                preview.className = 'max-w-[70%] max-h-[70%] object-contain';
                container.innerHTML = '';
                container.appendChild(preview);
            }
            preview.src = event.target.result;
        }
        reader.readAsDataURL(file);
    }
});

document.getElementById('faviconInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            let container = document.querySelectorAll('.w-24.h-24')[1]; // Second container for favicon
            let preview = document.getElementById('faviconPreview');
            if (!preview) {
                preview = document.createElement('img');
                preview.id = 'faviconPreview';
                preview.className = 'max-w-[50%] max-h-[50%] object-contain';
                container.innerHTML = '';
                container.appendChild(preview);
            }
            preview.src = event.target.result;
        }
        reader.readAsDataURL(file);
    }
});

document.getElementById('heroInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            let container = document.querySelector('.aspect-\\[21\\/9\\]');
            let preview = document.getElementById('heroPreview');
            if (!preview) {
                preview = document.createElement('img');
                preview.id = 'heroPreview';
                preview.className = 'w-full h-full object-cover';
                container.innerHTML = '';
                container.appendChild(preview);
            }
            preview.src = event.target.result;
        }
        reader.readAsDataURL(file);
    }
});
</script>
</body>
</html>
