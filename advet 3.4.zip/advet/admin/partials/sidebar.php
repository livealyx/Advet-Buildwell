<?php
// FILE: admin/partials/sidebar.php
// Reusable admin sidebar — included in all admin pages.
// Session must already be started before including this file.

$currentScript = basename($_SERVER['SCRIPT_FILENAME']);

function sidebarLink(string $href, string $label, string $icon, string $current, int $badge = 0): void {
    $isActive = (basename($href) === $current) || ($label === 'Overview' && $current === 'dashboard.php');
    $cls = $isActive
        ? 'bg-background/10 text-accent'
        : 'text-background/50 hover:bg-background/10 hover:text-background';
    echo '<a href="' . htmlspecialchars($href) . '" class="flex items-center justify-between px-5 py-3 mt-1 rounded-2xl text-[10px] font-bold uppercase tracking-[0.15em] transition-all ' . $cls . '">';
    echo '<div class="flex items-center gap-3">';
    echo '<span class="opacity-80">' . $icon . '</span>';
    echo '<span>' . htmlspecialchars($label) . '</span>';
    echo '</div>';
    if ($badge > 0) {
        echo '<span class="bg-red-500 text-white text-[9px] font-bold rounded-full px-2 py-0.5">' . $badge . '</span>';
    }
    echo '</a>';
}

// SVG Icons Dictionary (Hugeicons/Outline format)
$i_dash = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" /></svg>';
$i_list = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m0-13.5h3.75m-3.75 3h3.75m-3.75 3h3.75m-3.75 3h3.75m-9-12h3.75m-3.75 3h3.75m-3.75 3h3.75m-3.75 3h3.75" /></svg>';
$i_addp = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>';
$i_inq  = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.909A2.25 2.25 0 012.25 6.993V6.75" /></svg>';
$i_users= '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" /></svg>';
$i_addu = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" /></svg>';
$i_book = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" /></svg>';
$i_pen  = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" /></svg>';
$i_star = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-1.81.688l1.15 5.424c.123.582-.5.1.043-.225l-4.705-2.88a.563.563 0 00-.594 0l-4.705 2.88c-.5.305-1.116-.143-.996-.726l1.15-5.424a.563.563 0 00-.18-.688l-4.204-3.602c-.38-.325-.178-.948.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" /></svg>';
$i_file = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9zm3.75 11.625a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" /></svg>';
$i_chart= '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>';
$i_cog  = '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>';

// New inquiries badge
$newCount = 0;
$newFeedbackCount = 0;
try {
    require_once __DIR__ . '/../../config/db.php';
    $pdo = getPDO();
    $settings = loadSettings($pdo);
    $siteLogo = $settings['site_logo'] ?? '';
    
    $uid = (int)($_SESSION['user']['id'] ?? 0);
    $isAdmin = ($_SESSION['user']['role'] ?? '') === 'admin';

    if ($isAdmin) {
        $newCount = (int)$pdo->query("SELECT COUNT(*) FROM inquiries WHERE status='new'")->fetchColumn();
        $newFeedbackCount = (int)$pdo->query("SELECT COUNT(*) FROM testimonials WHERE status='pending'")->fetchColumn();
    } else {
        $stmt = $pdo->prepare("SELECT COUNT(i.id) FROM inquiries i JOIN properties p ON i.property_id = p.id WHERE i.status='new' AND p.agent_id = ?");
        $stmt->execute([$uid]);
        $newCount = (int)$stmt->fetchColumn();
    }
} catch (\Throwable $e) {}

$userName  = $_SESSION['user']['name'] ?? 'Admin';
$userRole  = $_SESSION['user']['role'] ?? 'member';
$isAdmin   = $userRole === 'admin';
$initials  = strtoupper(substr($userName, 0, 1)) . (strpos($userName, ' ') !== false ? strtoupper(substr(strrchr($userName, ' '), 1, 1)) : '');
?>
<!-- Premium Uploader Assets -->
<link rel="stylesheet" href="<?= BASE ?>assets/css/uploader.css">
<script src="<?= BASE ?>assets/js/uploader.js"></script>

<aside class="w-64 flex-shrink-0 bg-foreground text-background flex flex-col hidden lg:flex min-h-screen">
    <div class="p-8 pb-10 border-b border-background/5 mb-6">
        <a href="<?= BASE ?>" class="flex items-center gap-3">
            <?php if (!empty($siteLogo)): ?>
                <img src="<?= imgUrl($siteLogo) ?>" class="h-8 w-auto object-contain" alt="Logo">
            <?php else: ?>
                <svg class="w-6 h-6 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
                    <path d="M12 3l8 7L12 21l-8-11 8-7z"/><path d="M12 3v18"/><path d="M4 10l8 4 8-4"/>
                </svg>
            <?php endif; ?>
            <span class="text-sm font-serif font-medium tracking-wider"><?= e($settings['site_name'] ?? 'Advet Studio') ?></span>
        </a>
    </div>

    <nav class="flex-grow px-4 overflow-y-auto pb-12">
        <?php
        $isAgent = in_array($_SESSION['user']['role'] ?? '', ['admin', 'agent']);
        $isAdmin = ($_SESSION['user']['role'] ?? '') === 'admin';

        // 1. DASHBOARD
        sidebarLink(BASE . 'admin/dashboard.php',    'Overview',     $i_dash, $currentScript);
        sidebarLink(BASE . 'admin/profile.php',      'My Profile',   '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg>', $currentScript);

        // EXTRA SEPARATOR
        echo '<div class="h-px bg-background/5 my-6 mx-2"></div>';

        // 2. REAL ESTATE (Agents & Admin)
        if ($isAgent) {
            echo '<div class="mb-3 px-5 text-[9px] font-bold uppercase tracking-[0.25em] text-background/30 italic">Real Estate</div>';
            sidebarLink(BASE . 'admin/listings.php',     'All Listings', $i_list, $currentScript);
            sidebarLink(BASE . 'admin/add-property.php', 'Add Property', $i_addp, $currentScript);
            if ($isAdmin) {
                sidebarLink(BASE . 'admin/archetypes.php',      'Archetypes',   $i_dash, $currentScript);
                sidebarLink(BASE . 'admin/featured-projects.php', 'Highlights',   $i_star, $currentScript);
            }
            echo '<div class="h-4"></div>';
        }

        // 3. CRM & ENGAGEMENT
        if ($isAgent) {
            echo '<div class="mb-3 px-5 text-[9px] font-bold uppercase tracking-[0.25em] text-background/30 italic">Engagement</div>';
            sidebarLink(BASE . 'admin/inquiries.php',    'Inquiries',    $i_inq,  $currentScript, $newCount);
            if ($isAdmin) {
                sidebarLink(BASE . 'admin/testimonials.php', 'Testimonials', $i_star, $currentScript, $newFeedbackCount);
                sidebarLink(BASE . 'admin/visitors.php',     'Visitors',     '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>', $currentScript);
            }
            echo '<div class="h-4"></div>';
        }

        // 4. CONTENT MANAGEMENT
        if ($isAdmin) {
            echo '<div class="mb-3 px-5 text-[9px] font-bold uppercase tracking-[0.25em] text-background/30 italic">Content</div>';
            sidebarLink(BASE . 'admin/stories.php',      'All Stories',  $i_book, $currentScript);
            sidebarLink(BASE . 'admin/comments.php',     'Story Comments',$i_inq,  $currentScript);
            sidebarLink(BASE . 'admin/albums.php',       'Gallery',      '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>', $currentScript);
            sidebarLink(BASE . 'admin/faq.php',          'FAQ',          '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" /></svg>', $currentScript);
            sidebarLink(BASE . 'admin/team.php',         'Our Team',     $i_users, $currentScript);
            echo '<div class="h-4"></div>';
        }

        // 5. ADMINISTRATION & ACCESS
        if ($isAdmin) {
            echo '<div class="mb-3 px-5 text-[9px] font-bold uppercase tracking-[0.25em] text-background/30 italic">System</div>';
            sidebarLink(BASE . 'admin/users.php',        'Agents & Users', $i_users, $currentScript);
            sidebarLink(BASE . 'admin/analytics.php',    'Analytics',    $i_chart,$currentScript);
            sidebarLink(BASE . 'admin/pages.php',        'Legal Pages',  $i_file, $currentScript);
            sidebarLink(BASE . 'admin/settings.php',     'Settings',     $i_cog,  $currentScript);
            sidebarLink(BASE . 'admin/ai-settings.php',  'AI Chatbot',   '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a.75.75 0 01-1.074-.765 5.99 5.99 0 011.632-3.78c-1.31-1.308-2.118-3.003-2.118-4.875 0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" /></svg>',  $currentScript);
            sidebarLink(BASE . 'admin/theme.php',        'Theme',        '<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.648l3.813-6.873a.75.75 0 00-1.012-1.011l-6.874 3.813a16.036 16.036 0 00-4.648 4.764m3.42 3.42l-1.5 1.5M10.5 13.5l1.5-1.5" /></svg>', $currentScript);
            sidebarLink(BASE . 'admin/system.php',       'Maintenance',  $i_cog, $currentScript);
        }
        ?>
    </nav>

    <div class="mt-auto p-12 border-t border-background/10">
        <div class="flex items-center gap-4">
            <a href="<?= BASE ?>admin/profile.php" class="w-10 h-10 rounded-full bg-accent flex items-center justify-center font-bold text-sm text-foreground hover:ring-2 hover:ring-accent transition-all overflow-hidden relative group shrink-0">
                <?php if (!empty($_SESSION['user']['profile_picture'])): ?>
                    <img src="<?= imgUrl($_SESSION['user']['profile_picture']) ?>" alt="Profile" class="w-full h-full object-cover">
                <?php else: ?>
                    <?= htmlspecialchars($initials) ?>
                <?php endif; ?>
                <div class="absolute inset-0 bg-background/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg class="w-3 h-3 text-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125"/></svg>
                </div>
            </a>
            <div>
                <p class="text-[10px] font-bold uppercase tracking-widest leading-tight">
                    <a href="<?= BASE ?>admin/profile.php" class="hover:text-accent transition-colors"><?= htmlspecialchars($userName) ?></a>
                </p>
                <div class="flex gap-2 items-center mt-1 text-[9px] text-background/40">
                    <span class="uppercase tracking-widest"><?= htmlspecialchars($userRole) ?></span>
                    <span>·</span>
                    <a href="<?= BASE ?>auth/logout.php" class="hover:text-background transition-colors">Sign Out</a>
                </div>
            </div>
        </div>
    </div>
</aside><!-- 
    The Global Upload Progress Overlay is deprecated in favor of the new 
    Segmented Dot Uploader component which provides a more inline, premium experience.
-->
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Re-check for any late-added file inputs
    const obs = new MutationObserver((muts) => {
        muts.forEach(m => m.addedNodes.forEach(node => {
            if (node.nodeType === 1) {
                const inputs = node.querySelectorAll('input[type="file"][accept*="image"]');
                inputs.forEach(input => {
                    if (!input.dataset.uploaderActive) {
                        input.dataset.uploaderActive = "true";
                        new AdvetUploader(input);
                    }
                });
            }
        }));
    });
    obs.observe(document.body, { childList: true, subtree: true });
});
</script>

<?php include_once __DIR__ . '/../../includes/chat-widget.php'; ?>
