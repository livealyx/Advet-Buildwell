<?php
// FILE: admin/edit-property.php
session_start();
require_once '../config/db.php';
if (empty($_SESSION['user'])) {
    header('Location: ' . BASE . 'auth/login.php'); exit;
}
if (!in_array($_SESSION['user']['role'], ['admin', 'agent'])) {
    header('Location: ' . BASE . 'index.php'); exit;
}

$pdo = getPDO();
$userRole = $_SESSION['user']['role'];
$userId   = (int)$_SESSION['user']['id'];

$id  = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . BASE . 'admin/listings.php'); exit; }

$prop = $pdo->prepare("SELECT * FROM properties WHERE id = ?");
$prop->execute([$id]);
$p = $prop->fetch();
if (!$p || ($userRole === 'agent' && (int)$p['agent_id'] !== $userId)) {
    $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Property not found or unauthorized.'];
    header('Location: ' . BASE . 'admin/listings.php'); exit;
}

$agents = [];
if ($userRole === 'admin') {
    $agents = $pdo->query("SELECT id, name FROM users WHERE role = 'agent' ORDER BY name")->fetchAll();
}

$gallery = json_decode($p['gallery_images'] ?? '[]', true) ?: [];
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Property | Advet Studio</title>
    <script src="<?= BASE ?>assets/js/tailwind.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <?= getAdminTailwindConfig(isset($settings) ? $settings : []) ?>
    <link href="<?= BASE ?>assets/css/fonts.css" rel="stylesheet">
    <style>
        body{-webkit-font-smoothing:antialiased;} 
        .form-reveal{opacity:0;transform:translateY(20px);animation:fadeIn .8s cubic-bezier(.2,.8,.2,1) forwards}
        @keyframes fadeIn{to{opacity:1;transform:none}} 
        input:focus,textarea:focus,select:focus{outline:none;border-color:#899178;}

        /* Rich Text Editor */
        .editor-wrapper { border:1px solid rgba(223,216,204,0.4); border-radius:24px; background:rgba(244,240,230,0.2); transition:all 0.3s; }
        .editor-wrapper:focus-within { border-color:#899178; background:rgba(244,240,230,0.4); box-shadow:0 10px 40px rgba(137,145,120,0.06); }
        .editor-toolbar { display:flex; align-items:center; gap:2px; padding:10px 16px; background:rgba(253,252,249,0.85); backdrop-filter:blur(8px); border-bottom:1px solid rgba(223,216,204,0.3); border-radius:24px 24px 0 0; flex-wrap:wrap; position:sticky; top:0; z-index:10; overflow:visible; }
        .tb-btn { display:flex; align-items:center; justify-content:center; width:30px; height:30px; border-radius:8px; color:#6D685C; cursor:pointer; transition:all 0.2s; position:relative; overflow:visible; }
        .tb-btn:hover { background:rgba(137,145,120,0.1); color:#2A2925; transform:translateY(-1px); }
        .tb-btn svg { width:14px; height:14px; stroke:currentColor; stroke-width:1.8; }
        .tb-select { font-family:'Inter',sans-serif; font-size:11px; font-weight:500; color:#6D685C; background:transparent; border:1px solid rgba(223,216,204,0.4); border-radius:8px; padding:4px 8px; cursor:pointer; outline:none; }
        .tb-sep { width:1px; height:16px; background:rgba(223,216,204,0.6); margin:0 4px; }
        .tb-btn::after { content:attr(data-tip); position:absolute; top:calc(100% + 7px); left:50%; transform:translateX(-50%); background:#2A2925; color:#FDFCF9; font-size:9px; font-family:'Inter',sans-serif; letter-spacing:0.05em; white-space:nowrap; padding:3px 8px; border-radius:6px; pointer-events:none; opacity:0; z-index:100; transition:opacity 0.18s; }
        .tb-btn::before { content:''; position:absolute; top:calc(100% + 2px); left:50%; transform:translateX(-50%); border:4px solid transparent; border-bottom-color:#2A2925; pointer-events:none; opacity:0; z-index:100; transition:opacity 0.18s; }
        .tb-btn:hover::after, .tb-btn:hover::before { opacity:1; }
        .tb-color-btn { position:relative; }
        .tb-color-btn input[type=color] { position:absolute; inset:0; width:100%; height:100%; opacity:0; cursor:pointer; }
        .editor-content { min-height:250px; padding:32px; font-family:'Inter',sans-serif; font-size:14px; line-height:1.7; color:#2A2925; font-weight:300; outline:none; overflow-y:auto; border-radius:0 0 24px 24px; }
        .editor-content h2 { font-size:1.4em; font-family:'Cormorant Garamond',serif; font-style:italic; margin:1em 0 0.4em; border-bottom:1px solid rgba(223,216,204,0.5); padding-bottom:8px; }
        .editor-content p { margin-bottom:1em; }
        .editor-content ul { padding-left:1.5em; list-style-type:disc; margin-bottom:1em; }
        .editor-content blockquote { border-left:3px solid #899178; margin:1.2em 0; padding:1em 2em; background:rgba(137,145,120,0.05); font-style:italic; border-radius:0 16px 16px 0; }
    </style>
</head>
<body class="font-sans font-light min-h-screen bg-[#F4F1ED] flex" style="background-color: <?= $settings['theme_surface'] ?? '#F4F1ED' ?>">
<?php require_once '../includes/flash.php'; ?>
<?php include __DIR__ . '/partials/sidebar.php'; ?>

<main class="flex-grow p-8 sm:p-12 overflow-y-auto">
    <div class="max-w-4xl mx-auto">
        <div class="mb-12 form-reveal">
            <p class="text-[10px] font-bold uppercase tracking-[0.4em] text-accent mb-4">Edit Mode</p>
            <h1 class="text-4xl md:text-5xl font-serif font-light mb-4">Editing <span class="italic text-muted"><?= e($p['title']) ?></span></h1>
            <p class="text-sm text-muted">Modify the sanctuary details below. All changes will be reflected immediately.</p>
        </div>

        <form id="property-form" method="POST" action="<?= BASE ?>actions/save-property.php" enctype="multipart/form-data" class="space-y-10 form-reveal" style="animation-delay:.1s">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">

            <!-- Core Attributes -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Core Attributes</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="col-span-1 md:col-span-2">
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Property Title *</label>
                        <input type="text" name="title" required value="<?= e($p['title']) ?>"
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                    </div>
                    <div class="col-span-1 md:col-span-2">
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Location *</label>
                        <input type="text" name="location" required value="<?= e($p['location']) ?>"
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Asking Price *</label>
                        <input type="number" name="price" required min="0" step="0.01" value="<?= e($p['price']) ?>"
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Status</label>
                        <select name="status" class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all">
                            <?php foreach (['active','draft','sold'] as $st): ?>
                            <option value="<?= $st ?>" <?= $p['status'] === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Category *</label>
                        <select name="category" required class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all cursor-pointer">
                            <?php foreach (['Home','Plot','Commercial'] as $cat): ?>
                            <option value="<?= $cat ?>" <?= ($p['category'] ?? 'Home') === $cat ? 'selected' : '' ?>><?= $cat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Listing Type *</label>
                        <select name="listing_type" required class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all cursor-pointer">
                            <?php foreach (['Buy','Sell','Rent'] as $lt): ?>
                            <option value="<?= $lt ?>" <?= ($p['listing_type'] ?? 'Buy') === $lt ? 'selected' : '' ?>><?= $lt === 'Rent' ? 'Rent / Lease' : $lt ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <?php if ($_SESSION['user']['role'] === 'admin' && !empty($agents)): ?>
                <div class="mt-8 border-t border-sand/30 pt-8">
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Assigned Agent (Optional)</label>
                    <select name="agent_id" class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm appearance-none transition-all cursor-pointer">
                        <option value="">-- No Agent (Studio Owned) --</option>
                        <?php foreach ($agents as $ag): ?>
                        <option value="<?= $ag['id'] ?>" <?= $p['agent_id'] == $ag['id'] ? 'selected' : '' ?>><?= e($ag['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>

            <!-- Spatial Metrics -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Spatial Metrics</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-6">
                    <?php foreach ([['Bedrooms','bedrooms'],['Bathrooms','bathrooms'],['Square Footage','sqft']] as [$label,$name]): ?>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1"><?= $label ?></label>
                        <input type="number" name="<?= $name ?>" min="0" value="<?= (int)$p[$name] ?>"
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Materials & Description -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Material Palette & Atmosphere</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <?php foreach ([['Primary Material','primary_material'],['Secondary Material','secondary_material'],['Acoustic Stillness','acoustic_stillness']] as [$label,$name]): ?>
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1"><?= $label ?></label>
                        <input type="text" name="<?= $name ?>" value="<?= e($p[$name] ?? '') ?>"
                               class="w-full px-6 py-4 bg-surface/30 border border-sand/30 rounded-2xl text-sm transition-all">
                    </div>
                    <?php endforeach; ?>
                </div>
                <div>
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Property Description *</label>
                    <textarea name="description" id="prop_desc_input" class="hidden"><?= htmlspecialchars($p['description'] ?? '') ?></textarea>
                    
                    <div class="editor-wrapper shadow-sm">
                        <div class="editor-toolbar" data-target="editor">
                            <select class="tb-select mr-1" onchange="execBlock(this,'editor')">
                                <option value="div">Para</option>
                                <option value="h2">H2</option>
                                <option value="h3">H3</option>
                            </select>
                            <div class="tb-sep"></div>
                            <button type="button" class="tb-btn" data-tip="Bold" onclick="execFmt('bold','editor')"><svg viewBox="0 0 24 24" fill="none"><path d="M6 4h8a4 4 0 0 1 0 8H6z" stroke-linecap="round"/><path d="M6 12h9a4 4 0 0 1 0 8H6z" stroke-linecap="round"/></svg></button>
                            <button type="button" class="tb-btn" data-tip="Italic" onclick="execFmt('italic','editor')"><svg viewBox="0 0 24 24" fill="none"><line x1="15" y1="4" x2="9" y2="20" stroke-linecap="round"/></svg></button>
                            <div class="tb-sep"></div>
                            <button type="button" class="tb-btn" data-tip="List" onclick="execFmt('insertUnorderedList','editor')"><svg viewBox="0 0 24 24" fill="none"><line x1="9" y1="6" x2="20" y2="6" stroke-linecap="round"/><circle cx="4" cy="6" r="1" fill="currentColor"/></svg></button>
                            <button type="button" class="tb-btn" data-tip="Quote" onclick="insertBlockquote('editor')"><svg viewBox="0 0 24 24" fill="none"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" stroke-linecap="round"/></svg></button>
                            <div class="tb-sep"></div>
                            <button type="button" class="tb-btn tb-color-btn" data-tip="Color">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 7L4 19M15 7L20 19M6.5 13h11"/></svg>
                                <input type="color" value="#2A2925" oninput="document.execCommand('foreColor',false,this.value)">
                            </button>
                            <button type="button" class="tb-btn" data-tip="Link" onclick="insertLink('editor')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke-linecap="round"/></svg></button>
                            <span class="ml-auto text-[9px] uppercase tracking-widest text-muted/40 font-bold" id="desc-wc">0 words</span>
                        </div>
                        <div class="editor-content" id="editor" contenteditable="true" data-placeholder="Describe the sanctuary..." data-input="prop_desc_input" data-wc="desc-wc"></div>
                    </div>
                </div>
            </div>

            <!-- Visuals -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent mb-10 border-b border-sand pb-4">Visual Documentation</h2>

                <!-- Current Featured Image -->
                <?php if ($p['featured_image']): ?>
                <div class="mb-8">
                    <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-3">Current Featured Image</p>
                    <div class="flex items-start gap-6">
                        <img src="<?= imgUrl($p['featured_image']) ?>" alt="" class="w-40 h-28 object-cover rounded-2xl border border-sand/30">
                        <div>
                            <label class="flex items-center gap-2 cursor-pointer text-sm text-muted">
                                <input type="checkbox" name="remove_featured" value="1" class="accent-accent">
                                <span>Remove featured image</span>
                            </label>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="mb-8">
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">
                        <?= $p['featured_image'] ? 'Replace Featured Image' : 'Featured Image' ?>
                    </label>
                    <input type="file" name="featured_image" accept="image/jpeg,image/png,image/webp"
                           class="block w-full text-sm text-muted file:mr-4 file:py-3 file:px-6 file:rounded-2xl file:border-0 file:text-xs file:font-bold file:uppercase file:tracking-widest file:bg-surface file:text-foreground hover:file:bg-sand file:transition-all cursor-pointer">
                </div>

                <!-- Gallery Thumbnails -->
                <?php if (!empty($gallery)): ?>
                <div class="mb-8">
                    <p class="text-[10px] uppercase tracking-widest font-bold text-muted mb-4">Current Gallery Images</p>
                    <div class="grid grid-cols-3 sm:grid-cols-6 gap-4">
                        <?php foreach ($gallery as $i => $img): ?>
                        <div class="relative group">
                            <img src="<?= imgUrl($img) ?>" alt="" class="w-full aspect-square object-cover rounded-2xl border border-sand/30">
                            <label class="absolute inset-0 flex items-end justify-center pb-2 cursor-pointer bg-black/0 group-hover:bg-black/30 rounded-2xl transition-all">
                                <span class="flex items-center gap-1.5 bg-white/90 px-2 py-1 rounded-full text-[9px] font-bold uppercase opacity-0 group-hover:opacity-100 transition-opacity">
                                    <input type="checkbox" name="remove_gallery[]" value="<?= e($img) ?>" class="accent-red-500"> Remove
                                </span>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div>
                    <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-3 ml-1">Add Gallery Images</label>
                    <input type="file" name="gallery_images[]" accept="image/jpeg,image/png,image/webp" multiple
                           class="block w-full text-sm text-muted file:mr-4 file:py-3 file:px-6 file:rounded-2xl file:border-0 file:text-xs file:font-bold file:uppercase file:tracking-widest file:bg-surface file:text-foreground hover:file:bg-sand file:transition-all cursor-pointer">
                </div>
            </div>

            <!-- Actions -->
            <div class="flex flex-col sm:flex-row gap-4 pt-4 pb-20">
                <button type="submit" class="flex-1 py-5 bg-foreground text-background rounded-2xl text-xs font-bold uppercase tracking-[0.2em] transform hover:-translate-y-1 transition-all shadow-xl">
                    Save Changes
                </button>
                <a href="<?= BASE ?>admin/listings.php" class="px-10 py-5 border border-sand text-muted rounded-2xl text-xs font-bold uppercase tracking-[0.2em] hover:bg-surface transition-all text-center">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</main>
<script>
function getE(id){return document.getElementById(id);}
function execFmt(cmd,eI){getE(eI).focus();document.execCommand(cmd,false,null);sync(eI);}
function execBlock(sel,eI){getE(eI).focus();document.execCommand('formatBlock',false,sel.value);sel.value='div';sync(eI);}
function insertBlockquote(eI){getE(eI).focus();document.execCommand('formatBlock',false,'blockquote');sync(eI);}
function insertLink(eI){const u=prompt('URL:','https://');if(u){getE(eI).focus();document.execCommand('createLink',false,u);sync(eI);}}
function sync(eI){
    const e = getE(eI); const input = getE(e.dataset.input); const wc = getE(e.dataset.wc);
    input.value = e.innerHTML;
    const words = e.innerText.trim() ? e.innerText.trim().split(/\s+/).length : 0;
    wc.textContent = words + ' word' + (words!==1?'s':'');
}
document.addEventListener('DOMContentLoaded', () => {
    const e = getE('editor'); const input = getE(e.dataset.input); const raw = input.value;
    if (raw.trim().startsWith('<') || raw.includes('<p')) { e.innerHTML = raw; }
    else if (raw.trim()) { e.innerHTML = raw.split('\n').filter(l=>l.trim()).map(l=>'<p>'+l+'</p>').join(''); }
    sync('editor');
    e.addEventListener('input', () => sync('editor'));
    document.getElementById('property-form').addEventListener('submit', () => sync('editor'));
});
</script>
</body>
</html>
