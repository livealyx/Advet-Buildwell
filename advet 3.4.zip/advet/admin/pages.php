<?php
// FILE: admin/pages.php
session_start();
require_once '../config/db.php';
if (empty($_SESSION['user'])) {
    header('Location: ' . BASE . 'auth/login.php'); exit;
}
if ($_SESSION['user']['role'] !== 'admin') {
    header('Location: ' . BASE . 'index.php'); exit;
}

$pdo      = getPDO();
$settings = loadSettings($pdo);
$s = $settings; // shorthand
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legal Pages | Advet Studio</title>
    <script src="<?= BASE ?>assets/js/tailwind.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <?= getAdminTailwindConfig(isset($settings) ? $settings : []) ?>
    <link href="<?= BASE ?>assets/css/fonts.css" rel="stylesheet">
    <style>
        body { -webkit-font-smoothing: antialiased; }
        .form-reveal { opacity:0; transform:translateY(20px); animation:fadeIn .8s cubic-bezier(.2,.8,.2,1) forwards }
        @keyframes fadeIn { to { opacity:1; transform:none } }

        /* ── Rich Text Editor ─────────────────────────────────────── */
        .editor-wrapper {
            border: 1px solid rgba(223,216,204,0.5);
            border-radius: 24px;
            background: rgba(244,240,230,0.25);
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .editor-wrapper:focus-within {
            border-color: #899178;
            background: rgba(244,240,230,0.45);
            box-shadow: 0 10px 40px rgba(137,145,120,0.08);
        }

        /* Toolbar */
        .editor-toolbar {
            display: flex;
            align-items: center;
            gap: 2px;
            padding: 10px 16px;
            background: rgba(253,252,249,0.85);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid rgba(223,216,204,0.45);
            border-radius: 24px 24px 0 0;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 10;
            overflow: visible;
        }
        .tb-sep {
            width: 1px;
            height: 20px;
            background: rgba(223,216,204,0.7);
            margin: 0 4px;
            flex-shrink: 0;
        }
        .tb-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            border: none;
            background: transparent;
            color: #6D685C;
            cursor: pointer;
            transition: background 0.15s, color 0.15s, transform 0.1s;
            flex-shrink: 0;
            font-size: 13px;
            font-weight: 500;
            font-family: 'Inter', sans-serif;
            line-height: 1;
            position: relative;
        }
        .tb-btn:hover {
            background: rgba(137,145,120,0.12);
            color: #2A2925;
            transform: translateY(-1px);
        }
        .tb-btn.active {
            background: rgba(137,145,120,0.2);
            color: #2A2925;
        }
        .tb-btn svg {
            width: 15px;
            height: 15px;
            stroke: currentColor;
            stroke-width: 1.8;
        }
        .tb-select {
            font-family: 'Inter', sans-serif;
            font-size: 11px;
            font-weight: 500;
            letter-spacing: 0.04em;
            color: #6D685C;
            background: transparent;
            border: 1px solid rgba(223,216,204,0.5);
            border-radius: 8px;
            padding: 4px 8px;
            appearance: none;
            -webkit-appearance: none;
            cursor: pointer;
            outline: none;
            transition: border-color 0.2s;
        }
        .tb-select:hover, .tb-select:focus {
            border-color: #899178;
            color: #2A2925;
        }
        .tb-color-btn {
            position: relative;
        }
        .tb-color-btn input[type=color] {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
            border: none;
            padding: 0;
        }

        /* Tooltip */
        .tb-btn {
            overflow: visible;
        }
        .tb-btn::after {
            content: attr(data-tip);
            position: absolute;
            top: calc(100% + 7px);
            left: 50%;
            transform: translateX(-50%);
            background: #2A2925;
            color: #FDFCF9;
            font-size: 9px;
            font-family: 'Inter', sans-serif;
            letter-spacing: 0.06em;
            white-space: nowrap;
            padding: 3px 8px;
            border-radius: 6px;
            pointer-events: none;
            opacity: 0;
            z-index: 100;
            transition: opacity 0.18s;
        }
        /* tiny arrow pointing up */
        .tb-btn::before {
            content: '';
            position: absolute;
            top: calc(100% + 2px);
            left: 50%;
            transform: translateX(-50%);
            border: 4px solid transparent;
            border-bottom-color: #2A2925;
            pointer-events: none;
            opacity: 0;
            z-index: 100;
            transition: opacity 0.18s;
        }
        .tb-btn:hover::after,
        .tb-btn:hover::before { opacity: 1; }

        /* Content area */
        .editor-content {
            min-height: 380px;
            padding: 32px 40px;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            line-height: 1.85;
            color: #2A2925;
            font-weight: 300;
            outline: none;
            overflow-y: auto;
            border-radius: 0 0 24px 24px;
        }
        .editor-content:empty::before {
            content: attr(data-placeholder);
            color: rgba(109,104,92,0.45);
            pointer-events: none;
        }
        .editor-content h1 { font-size: 1.6em; font-weight: 600; margin: 1.2em 0 0.5em; font-family: 'Cormorant Garamond', serif; }
        .editor-content h2 { font-size: 1.35em; font-weight: 600; margin: 1em 0 0.4em; font-family: 'Cormorant Garamond', serif; }
        .editor-content h3 { font-size: 1.15em; font-weight: 600; margin: 0.8em 0 0.3em; }
        .editor-content p  { margin: 0 0 0.75em; }
        .editor-content ul, .editor-content ol { padding-left: 1.6em; margin: 0.5em 0 0.75em; }
        .editor-content li { margin-bottom: 0.3em; }
        .editor-content blockquote {
            border-left: 3px solid #899178;
            margin: 1em 0;
            padding: 0.5em 1.2em;
            background: rgba(137,145,120,0.06);
            border-radius: 0 12px 12px 0;
            color: #6D685C;
            font-style: italic;
        }
        .editor-content a { color: #899178; text-decoration: underline; }
        .editor-content hr { border: none; border-top: 1px solid rgba(223,216,204,0.6); margin: 1.5em 0; }
        .editor-content table { border-collapse: collapse; width: 100%; margin: 1em 0; }
        .editor-content td, .editor-content th {
            border: 1px solid rgba(223,216,204,0.6);
            padding: 8px 12px;
            font-size: 13px;
        }
        .editor-content th { background: rgba(244,240,230,0.5); font-weight: 600; }
        .editor-content pre, .editor-content code {
            font-family: 'Courier New', monospace;
            background: rgba(244,240,230,0.6);
            border-radius: 6px;
            padding: 2px 6px;
            font-size: 12px;
        }
        .editor-content pre { padding: 12px 16px; display: block; overflow-x: auto; }
    </style>
</head>
<body class="font-sans font-light min-h-screen bg-[#F4F1ED] flex" style="background-color: <?= $settings['theme_surface'] ?? '#F4F1ED' ?>">
<?php require_once '../includes/flash.php'; ?>
<?php include __DIR__ . '/partials/sidebar.php'; ?>

<main class="flex-grow p-8 sm:p-12 overflow-y-auto">
    <div class="max-w-4xl mx-auto">
        <div class="mb-12 form-reveal">
            <p class="text-[10px] font-bold uppercase tracking-[0.4em] text-accent mb-4">Content Management</p>
            <h1 class="text-4xl font-serif font-light italic">Legal <span class="text-muted">Pages</span></h1>
        </div>

        <form id="pagesForm" method="POST" action="<?= BASE ?>actions/save-pages.php" class="space-y-10 form-reveal" style="animation-delay:.1s">
            <!-- Legal Pages -->
            <div class="bg-background p-8 md:p-12 rounded-[2.5rem] shadow-sm border border-sand/40">
                <div class="flex items-center justify-between mb-10 border-b border-sand pb-4">
                    <h2 class="text-xs uppercase tracking-[0.3em] font-bold text-accent">Privacy &amp; Terms</h2>
                    <p class="text-[10px] text-muted italic">Used in the footer and main navigation links.</p>
                </div>

                <div class="space-y-14">

                    <!-- ── Privacy Policy Editor ─────────────────── -->
                    <div>
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Privacy Policy</label>
                        <!-- Hidden textarea synced to editor -->
                        <textarea name="settings[privacy_policy]" id="privacy_policy_input" class="hidden"><?= htmlspecialchars($s['privacy_policy'] ?? '') ?></textarea>

                        <div class="editor-wrapper shadow-sm" id="privacy-editor-wrap">
                            <!-- Toolbar -->
                            <div class="editor-toolbar" id="privacy-toolbar" data-target="privacy_editor">
                                <?php /* Heading select */ ?>
                                <select class="tb-select mr-2" onchange="execBlock(this,'privacy_editor')" title="Heading">
                                    <option value="div">Paragraph</option>
                                    <option value="h1">Heading 1</option>
                                    <option value="h2">Heading 2</option>
                                    <option value="h3">Heading 3</option>
                                    <option value="pre">Code Block</option>
                                </select>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Bold" onclick="execFmt('bold','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 4h8a4 4 0 0 1 0 8H6z" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 12h9a4 4 0 0 1 0 8H6z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Italic" onclick="execFmt('italic','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="19" y1="4" x2="10" y2="4" stroke-linecap="round"/><line x1="14" y1="20" x2="5" y2="20" stroke-linecap="round"/><line x1="15" y1="4" x2="9" y2="20" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Underline" onclick="execFmt('underline','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 3v7a6 6 0 0 0 12 0V3" stroke-linecap="round"/><line x1="4" y1="21" x2="20" y2="21" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Strikethrough" onclick="execFmt('strikeThrough','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M17.3 6.3a4 4 0 0 0-6.6 1.7" stroke-linecap="round"/><path d="M6.7 17.7a4 4 0 0 0 6.6-1.7" stroke-linecap="round"/><line x1="4" y1="12" x2="20" y2="12" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Align Left" onclick="execFmt('justifyLeft','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="3" y1="12" x2="15" y2="12" stroke-linecap="round"/><line x1="3" y1="18" x2="18" y2="18" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Align Center" onclick="execFmt('justifyCenter','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="6" y1="12" x2="18" y2="12" stroke-linecap="round"/><line x1="4" y1="18" x2="20" y2="18" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Align Right" onclick="execFmt('justifyRight','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="9" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="6" y1="18" x2="21" y2="18" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Bullet List" onclick="execFmt('insertUnorderedList','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="9" y1="6" x2="20" y2="6" stroke-linecap="round"/><line x1="9" y1="12" x2="20" y2="12" stroke-linecap="round"/><line x1="9" y1="18" x2="20" y2="18" stroke-linecap="round"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Numbered List" onclick="execFmt('insertOrderedList','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="10" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="10" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="10" y1="18" x2="21" y2="18" stroke-linecap="round"/><text x="2" y="8" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">1.</text><text x="2" y="14" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">2.</text><text x="2" y="20" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">3.</text></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Blockquote" onclick="insertBlockquote('privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Insert Link" onclick="insertLink('privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Horizontal Rule" onclick="execFmt('insertHorizontalRule','privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="3" y1="7" x2="7" y2="7" stroke-linecap="round"/><line x1="3" y1="17" x2="7" y2="17" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <!-- Text Color -->
                                <button type="button" class="tb-btn tb-color-btn" data-tip="Text Color">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M9 7L4 19"/><path d="M15 7L20 19"/><path d="M6.5 13h11"/><path d="M5 19.5c0-.5.2-1 1-1 1 0 1 1 2 1s1-1 2-1 1 1 2 1 1-1 2-1 1 1 2 1"/></svg>
                                    <input type="color" value="#2A2925" title="Text Color" oninput="document.execCommand('foreColor',false,this.value)">
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Clear Format" onclick="clearFmt('privacy_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 19l7-14" stroke-linecap="round"/><path d="M18 19l-7-14" stroke-linecap="round"/><line x1="3" y1="19" x2="21" y2="19" stroke-linecap="round"/><line x1="9.5" y1="5" x2="18.5" y2="19" stroke-linecap="round" stroke-dasharray="2 2"/></svg>
                                </button>

                                <!-- Word count -->
                                <span class="ml-auto text-[9px] uppercase tracking-widest text-muted/50 font-medium" id="privacy-wc">0 words</span>
                            </div>

                            <!-- Editable area -->
                            <div class="editor-content"
                                 id="privacy_editor"
                                 contenteditable="true"
                                 data-placeholder="Enter your privacy policy content here…"
                                 data-input="privacy_policy_input"
                                 data-wc="privacy-wc"
                                 spellcheck="true"></div>
                        </div>
                    </div>

                    <!-- ── Terms of Use Editor ───────────────────── -->
                    <div class="pt-10 border-t border-sand/30">
                        <label class="block text-[10px] uppercase tracking-widest font-bold text-muted mb-4 ml-1">Terms of Use</label>
                        <textarea name="settings[terms_of_use]" id="terms_of_use_input" class="hidden"><?= htmlspecialchars($s['terms_of_use'] ?? '') ?></textarea>

                        <div class="editor-wrapper shadow-sm" id="terms-editor-wrap">
                            <!-- Toolbar -->
                            <div class="editor-toolbar" id="terms-toolbar" data-target="terms_editor">
                                <select class="tb-select mr-2" onchange="execBlock(this,'terms_editor')" title="Heading">
                                    <option value="div">Paragraph</option>
                                    <option value="h1">Heading 1</option>
                                    <option value="h2">Heading 2</option>
                                    <option value="h3">Heading 3</option>
                                    <option value="pre">Code Block</option>
                                </select>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Bold" onclick="execFmt('bold','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 4h8a4 4 0 0 1 0 8H6z" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 12h9a4 4 0 0 1 0 8H6z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Italic" onclick="execFmt('italic','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="19" y1="4" x2="10" y2="4" stroke-linecap="round"/><line x1="14" y1="20" x2="5" y2="20" stroke-linecap="round"/><line x1="15" y1="4" x2="9" y2="20" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Underline" onclick="execFmt('underline','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 3v7a6 6 0 0 0 12 0V3" stroke-linecap="round"/><line x1="4" y1="21" x2="20" y2="21" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Strikethrough" onclick="execFmt('strikeThrough','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M17.3 6.3a4 4 0 0 0-6.6 1.7" stroke-linecap="round"/><path d="M6.7 17.7a4 4 0 0 0 6.6-1.7" stroke-linecap="round"/><line x1="4" y1="12" x2="20" y2="12" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Align Left" onclick="execFmt('justifyLeft','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="3" y1="12" x2="15" y2="12" stroke-linecap="round"/><line x1="3" y1="18" x2="18" y2="18" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Align Center" onclick="execFmt('justifyCenter','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="6" y1="12" x2="18" y2="12" stroke-linecap="round"/><line x1="4" y1="18" x2="20" y2="18" stroke-linecap="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Align Right" onclick="execFmt('justifyRight','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="9" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="6" y1="18" x2="21" y2="18" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Bullet List" onclick="execFmt('insertUnorderedList','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="9" y1="6" x2="20" y2="6" stroke-linecap="round"/><line x1="9" y1="12" x2="20" y2="12" stroke-linecap="round"/><line x1="9" y1="18" x2="20" y2="18" stroke-linecap="round"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Numbered List" onclick="execFmt('insertOrderedList','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="10" y1="6" x2="21" y2="6" stroke-linecap="round"/><line x1="10" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="10" y1="18" x2="21" y2="18" stroke-linecap="round"/><text x="2" y="8" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">1.</text><text x="2" y="14" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">2.</text><text x="2" y="20" font-size="7" fill="currentColor" stroke="none" font-family="Inter,sans-serif">3.</text></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Blockquote" onclick="insertBlockquote('terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Insert Link" onclick="insertLink('terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <button type="button" class="tb-btn" data-tip="Horizontal Rule" onclick="execFmt('insertHorizontalRule','terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><line x1="3" y1="12" x2="21" y2="12" stroke-linecap="round"/><line x1="3" y1="7" x2="7" y2="7" stroke-linecap="round"/><line x1="3" y1="17" x2="7" y2="17" stroke-linecap="round"/></svg>
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn tb-color-btn" data-tip="Text Color">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M9 7L4 19"/><path d="M15 7L20 19"/><path d="M6.5 13h11"/><path d="M5 19.5c0-.5.2-1 1-1 1 0 1 1 2 1s1-1 2-1 1 1 2 1 1-1 2-1 1 1 2 1"/></svg>
                                    <input type="color" value="#2A2925" title="Text Color" oninput="document.execCommand('foreColor',false,this.value)">
                                </button>

                                <div class="tb-sep"></div>

                                <button type="button" class="tb-btn" data-tip="Clear Format" onclick="clearFmt('terms_editor')">
                                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 19l7-14" stroke-linecap="round"/><path d="M18 19l-7-14" stroke-linecap="round"/><line x1="3" y1="19" x2="21" y2="19" stroke-linecap="round"/><line x1="9.5" y1="5" x2="18.5" y2="19" stroke-linecap="round" stroke-dasharray="2 2"/></svg>
                                </button>

                                <span class="ml-auto text-[9px] uppercase tracking-widest text-muted/50 font-medium" id="terms-wc">0 words</span>
                            </div>

                            <div class="editor-content"
                                 id="terms_editor"
                                 contenteditable="true"
                                 data-placeholder="Enter your terms of use content here…"
                                 data-input="terms_of_use_input"
                                 data-wc="terms-wc"
                                 spellcheck="true"></div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Page Meta -->
            <div class="bg-surface/40 p-6 rounded-2xl border border-sand/20 flex items-center gap-4">
                <div class="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center text-accent">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <p class="text-[11px] text-muted leading-relaxed">
                    Changes here will reflect instantly on the <a href="<?= BASE ?>public/privacy-policy.php" target="_blank" class="text-accent underline">Privacy Policy</a> and <a href="<?= BASE ?>public/terms-of-use.php" target="_blank" class="text-accent underline">Terms of Use</a> public pages.
                </p>
            </div>

            <!-- Save -->
            <div class="flex gap-4 pt-4 pb-20">
                <button type="submit"
                        class="flex-1 py-5 bg-foreground text-background rounded-2xl text-xs font-bold uppercase tracking-[0.2em] transform hover:-translate-y-1 transition-all shadow-xl">
                    Save Legal Pages
                </button>
            </div>
        </form>
    </div>
</main>

<script>
/* ── Editor Helpers ───────────────────────────────────────────────── */
function getEditor(id) { return document.getElementById(id); }

function execFmt(cmd, editorId) {
    getEditor(editorId).focus();
    document.execCommand(cmd, false, null);
    syncAll(editorId);
}

function execBlock(sel, editorId) {
    getEditor(editorId).focus();
    document.execCommand('formatBlock', false, sel.value);
    sel.value = 'div'; // reset select
    syncAll(editorId);
}

function insertBlockquote(editorId) {
    getEditor(editorId).focus();
    document.execCommand('formatBlock', false, 'blockquote');
    syncAll(editorId);
}

function insertLink(editorId) {
    const url = prompt('Enter URL:', 'https://');
    if (url) {
        getEditor(editorId).focus();
        document.execCommand('createLink', false, url);
        syncAll(editorId);
    }
}

function clearFmt(editorId) {
    getEditor(editorId).focus();
    document.execCommand('removeFormat', false, null);
    document.execCommand('formatBlock', false, 'div');
    syncAll(editorId);
}

function syncAll(editorId) {
    const editor = getEditor(editorId);
    const inputId = editor.dataset.input;
    const wcId    = editor.dataset.wc;
    // Sync hidden textarea
    document.getElementById(inputId).value = editor.innerHTML;
    // Word count
    const text = editor.innerText.trim();
    const words = text ? text.split(/\s+/).length : 0;
    document.getElementById(wcId).textContent = words + ' word' + (words !== 1 ? 's' : '');
}

/* ── Init: populate editors from hidden textareas ──────────────── */
document.addEventListener('DOMContentLoaded', function () {
    const editors = document.querySelectorAll('.editor-content[contenteditable]');
    editors.forEach(function(editor) {
        const inputId = editor.dataset.input;
        const raw = document.getElementById(inputId).value;
        // If content looks like HTML, inject it; otherwise treat as plain text
        if (raw.trim().startsWith('<') || raw.includes('<p') || raw.includes('<h')) {
            editor.innerHTML = raw;
        } else if (raw.trim()) {
            // Convert plain text lines to paragraphs
            editor.innerHTML = raw.split('\n').filter(l => l.trim()).map(l => '<p>' + l.replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</p>').join('');
        }
        // Initial word count
        syncAll(editor.id);

        // Sync on every input
        editor.addEventListener('input', function() { syncAll(editor.id); });

        // Sync before form submit
        document.getElementById('pagesForm').addEventListener('submit', function() {
            document.getElementById(inputId).value = editor.innerHTML;
        });
    });
});
</script>

</body>
</html>
